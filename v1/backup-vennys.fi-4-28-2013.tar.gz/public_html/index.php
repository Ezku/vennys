<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset="utf8" />
<title>Domain - <?php echo $_SERVER["HTTP_HOST"]; ?> - Hostingpalvelu.fi</title>
</head>
<body>
<img src="http://www.hostingpalvelu.fi/hostingpalvelufi.png">
<h1>Webhotelli domainille: <?php echo $_SERVER["HTTP_HOST"]; ?></h1>
<p>Tähän webhotelliin avautuu lähiaikoina asiakkaamme sivut.</p>
<p>Asiakassivuille voit kirjautua <a href="https://www.hostingpalvelu.fi/asiakkaat/clientarea.php">tästä</a></p>
<p>Suomen Hostingpalvelu Oy - Domainit ja webhotellit nopeasti ja luotettavasti <a href=http://www.hostingpalvelu.fi>www.hostingpalvelu.fi</a></p>
</body>
</html>
