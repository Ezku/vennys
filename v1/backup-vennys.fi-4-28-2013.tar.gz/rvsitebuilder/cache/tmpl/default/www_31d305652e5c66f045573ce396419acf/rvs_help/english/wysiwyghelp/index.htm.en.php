<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("RVSiteBuilder WYSIWYG VDO Tutorial");?></title>
<style type="text/css">
body { 
	font-size:62.8%;
	margin:0;
	padding:0;
	color:#515151;
	background-color:#E7E7E7;
}
table { 
	font-size: 1.0em;
 	font-family:Tahoma, Verdana;
}
.helpoverview{
	background-color:#F7F5F5; 
	color:#333333;
	margin:0px;
	padding:0px;
}
.helpoverview .title{
	color:#ffffff;
	font-size:13px;
	font-weight:bold;
	background-image:url(<?php echo htmlspecialchars($t->helpPath);?>/images/bgtitle.jpg);
	background-position:bottom;
	background-repeat:repeat-x;
	background-color:#89B65B;
	padding:2px 5px;
	text-align:left;
}
.helpoverview .content{
	font-size:12px;
	color:#333333;
	font-weight:bold;
	padding:20px 5px;
}
.helpoverview .content02{
	font-size:12px;
	color:#333333;
	font-weight:bold;
	padding:15px 5px 5px 200px;
	background-color:#E7E7E7;
}
a.btnclose:link ,a.btnclose:visited {
	background-image:url(<?php echo htmlspecialchars($t->helpPath);?>/images/btnclose.jpg);
	background-repeat:no-repeat;
	background-position:top right;
	display:block;
	width:26px;
	height:26px;
}
a.btnclose:hover ,a.btnclose:active {
	background-image:url(<?php echo htmlspecialchars($t->helpPath);?>/images/btnclose.jpg);
}
ul{font-weight:normal;}
a:link ,a:visited {
	color:#515151;
}
a:hover ,a:active {
	color:#FF3300;
}
</style>
<script>
function closeParentPOP(){
try{
window.opener.close()
}catch(e){}
this.close()
}


</script>


</head>

<body>
<table cellpadding="0" cellspacing="0" class="helpoverview" width="100%">
  	<tr>
    	<td width="99%" class="title"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("SiteBuilder Helpe");?></td>
		<td class="title"><a href="#" class="btnclose" OnClick="closeParentPOP()"></a></td>
  	</tr>
	<tr>
		<td colspan="2" align="left" valign="top">
			<table cellpadding="0" cellspacing="0" width="100%">
			  <tr>
			  	<td width="200" valign="bottom" align="center"><img src="<?php echo htmlspecialchars($t->helpPath);?>/images/icon_help.gif" alt="" width="150" height="149" /></td>
				 <td class="content" align="left" valign="top">
					<p><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("These video tutorials");?> </p>
					<p><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Basic tutorials:");?></p>
					<ul>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/toolbars"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Toolbars:"));?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/create_table"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Create Table:"));?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/copy_content"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Copy Content from MS Words:");?></a></li>
						<li><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upload Image:");?>
							<ul style="padding:5px 0px 10px 18px; margin:0;">
								<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/upload_image"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upload Image and Image Properties:");?> </a></li>
								<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/ResizeImage"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Resize Image:");?></a></li>
							</ul>
						</li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/hyperlink"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Text and Image Hyperlink:");?> </a></li>	
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/list"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("List:");?></a></li>						
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/spacial_character"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Special Characters:");?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/alignment"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Alignment:");?></a></li>							
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/search_replace"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Search and Replace:");?></a></li>	
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/bookmark"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Bookmark:");?></a></li>
					</ul>			
				</td>
			  </tr>
			  <tr>
			  	<td valign="top" align="center" bgcolor="#E7E7E7"><img src="<?php echo htmlspecialchars($t->helpPath);?>/images/icon_help02.gif" alt="" width="150" height="149" /></td>
				<td align="left" valign="top" class="content02"></td>
			  </tr>
			</table>
		</td>
  	</tr>
</table>
</body>
</html>
