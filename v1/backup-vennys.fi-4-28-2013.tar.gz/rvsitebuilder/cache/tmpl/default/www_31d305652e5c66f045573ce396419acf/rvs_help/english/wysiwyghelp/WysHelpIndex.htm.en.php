<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("RVSiteBuilder WYSIWYG VDO Tutorial");?></title>
<style type="text/css">
body { 
	font-size:62.8%;
	margin:0;
	padding:0;
	color:#515151;
}
table { 
	font-size: 1.0em;
 	font-family:Tahoma, Verdana;
}
.helpoverview{
	color:#333333;
	margin:0px;
	padding:0px;
}
.helpoverview .title{
	color:#ffffff;
	font-size:13px;
	font-weight:bold;
	background-image:url(<?php echo htmlspecialchars($t->helpPath);?>/images/bgtitle.jpg);
	background-position:bottom;
	background-repeat:repeat-x;
	padding:2px 5px;
	text-align:left;
}
.helpoverview .content{
	font-size:12px;
	color:#333333;
	font-weight:bold;
	padding:5px 5px 5px 20px;
}
.helpoverview .content02{
	font-size:12px;
	color:#333333;
	font-weight:bold;
	padding:5px 5px 5px 20px;
}
a.btnclose:link ,a.btnclose:visited {
	background-image:url(<?php echo htmlspecialchars($t->helpPath);?>/images/btnclose.jpg);
	background-repeat:no-repeat;
	background-position:top right;
	display:block;
	width:26px;
	height:26px;
}
a.btnclose:hover ,a.btnclose:active {
	background-image:url(<?php echo htmlspecialchars($t->helpPath);?>/images/btnclose.jpg);
}
ul{font-weight:normal;}
a:link ,a:visited {
	color:#515151;
}
a:hover ,a:active {
	color:#FF3300;
}
</style>

<script>
function closeParentPOP(){
try{
window.opener.close()
}catch(e){}
this.close()
}

</script>

</head>

<body>
<table cellpadding="0" cellspacing="0" class="helpoverview" width="100%">
	<tr>
		<td colspan="2" align="left" valign="top">
			<table cellpadding="0" cellspacing="0" width="100%">
			  <tr>
			  	<td colspan="2" align="left" valign="top" class="content"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("These video tutorials");?></td>
			  </tr>
			  <tr>
				 <td class="content" align="left" valign="top" width="50%">
					<p><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Basic tutorials:");?></p>
					<ul>
					  	 <li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/toolbars/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Toolbars:"));?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/create_table/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Create Table:"));?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/border_management/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Table Border Management:"));?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/copy_content/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Copy Content from MS Words:");?></a></li>
						<li><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upload Image:");?>
							<ul style="padding:5px 0px 10px 18px; margin:0;">
								<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/upload_image/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upload Image and Image Properties:");?> </a></li>
								<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/ResizeImage/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Resize Image:");?></a></li>
							</ul>
						</li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/hyperlink/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Text and Image Hyperlink:");?> </a></li>	
					</ul>			
				</td>
				<td align="left" valign="top" class="content">
					<p>&nbsp;</p>
					<ul>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/list/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("List:");?></a></li>						
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/spacial_character/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Special Characters:");?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/alignment/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Alignment:");?></a></li>							
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/search_replace/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Search and Replace:");?></a></li>	
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/bookmark/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Bookmark:");?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/LinkDocument/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("LinkDocument:");?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/edit_images/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit Image:");?></a></li>
						<li><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/media_manager/backto/WysHelpIndex"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Add Media object:");?></a></li>
					</ul>
				</td>
			  </tr>
			 </table>
		</td>
  	</tr>
</table>
</body>
</html>
