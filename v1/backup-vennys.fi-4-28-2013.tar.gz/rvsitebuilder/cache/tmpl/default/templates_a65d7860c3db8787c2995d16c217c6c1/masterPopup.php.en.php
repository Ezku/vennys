<?php
// This file is master template for Online form , Layout Template
include_once(WYSIWYG_ROOT_PATH . '/config.bridge.php');
include_once(WYSIWYG_ROOT_PATH . '/editor_functions.php');
include_once(WYSIWYG_ROOT_PATH . '/includes/common.php');
include_once(WYSIWYG_ROOT_PATH . '/lang/' . $lang_include);
?>
<html>
<head>
	<title><?php echo htmlspecialchars($t->siteName);?> :: <?php echo htmlspecialchars($t->pageTitle);?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo htmlspecialchars($t->charset);?>" />
	<meta http-equiv="Content-Language" content="<?php echo htmlspecialchars($t->currLang);?>" />
	<!-- Support IE 6 / IE 7 open dialog submit form -->
	<base target="_self" />

<style type="text/css" media="screen">
	<?php if ($t->phpSuExecRoot)  {?>
	    @import url("<?php echo htmlspecialchars($t->phpSuExecRoot);?>/www/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/css/style.php?charset=<?php echo htmlspecialchars($t->charset);?>");
	<?php } else {?>
        @import url("<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/css/style.php?charset=<?php echo htmlspecialchars($t->charset);?>");
	<?php }?>
    </style>

<script language="JavaScript" type="text/javascript" src="<?php echo htmlspecialchars($t->webRoot);?>/js/dirtyForm.js"></script>
    <?php echo $t->scriptOpen;?>
	    <?php if ($this->options['strict'] || (is_array($t->onReadyDom)  || is_object($t->onReadyDom))) foreach($t->onReadyDom as $eventHandler) {?>
	        sgl.ready("<?php echo htmlspecialchars($eventHandler);?>");
	    <?php }?>
	    <?php if ($t->onLoad)  {?>
	    window.onload = function() {
	        <?php if ($this->options['strict'] || (is_array($t->onLoad)  || is_object($t->onLoad))) foreach($t->onLoad as $eventHandler) {?>
	        <?php echo htmlspecialchars($eventHandler);?>;
	        <?php }?>
	    }
	    <?php }?>
	    <?php if ($t->onUnload)  {?>
	    window.onunload = function() {
	        <?php if ($this->options['strict'] || (is_array($t->onUnload)  || is_object($t->onUnload))) foreach($t->onUnload as $eventHandler) {?>
	        <?php echo htmlspecialchars($eventHandler);?>;
	        <?php }?>
	    }
	    <?php }?>
    <?php echo $t->scriptClose;?>

<script type="text/javascript">
<!--
var agrCustomClass = "['divOpenTab1','openActive'],['divLinkTab1','linkActive'],['divCloseTab1','closeActive'],['divOpenTab2','openCurrent'],['divLinkTab2','linkCurrent'],['divCloseTab2','closeCurrent']";
var agrTemplateClass = "['divOpenTab2','openActive'],['divLinkTab2','linkActive'],['divCloseTab2','closeActive'],['divOpenTab1','openCurrent'],['divLinkTab1','linkCurrent'],['divCloseTab1','closeCurrent']";
var agrTemplateDiv = "['onlineformTemplate','block'],['customdesign','none']";
var agrCustomDiv = "['customdesign','block'],['onlineformTemplate','none']";
var syntaxDisplay = "['.style.display=valueParameter']";
var syntaxSetAtt = "['.setAttribute(<!--singleQuote--!>class<!--singleQuote--!>,valueParameter)']";
var cmdDisplayTemplate = "DomPropertyHandle(" + syntaxDisplay + ',' + agrTemplateDiv + ");DomPropertyHandle(" + syntaxSetAtt + ',' + agrTemplateClass + ");";
var cmdDisplayCustom = "DomPropertyHandle(" + syntaxDisplay + ',' + agrCustomDiv + ");DomPropertyHandle(" + syntaxSetAtt + ',' + agrCustomClass + ");"; 
//-->
</script>

</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" style="<?php echo htmlspecialchars($t->style);?>background-color:#FFFFFF; padding:0;margin:0;">
	<table cellpadding="0" cellspacing="0" width="100%">
		<tr>
			<td id="framePopup">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/framePopup01.gif" alt="" width="8" height="8" /></td>
					<td width="99%" id="topframe"></td>
					<td><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/framePopup03.gif" alt="" width="6" height="8" /></td>
				</tr>
				<tr>
					<td valign="top" id="left"><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/framePopup04.gif" alt="" width="8" height="28" /></td>
					<td valign="top" id="blockPopup">
					<div>
					<div id="titleBar">
					<div class="title" id="pagetitle"><?php echo htmlspecialchars($t->pageTitle);?></div>
					<div style="float:right;"><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/help_popup.gif" alt="" width="27" height="27" /></div>
					</div>
					<div id="shadow"></div>
					<div>
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td id="rvsPopUpHtmlContent">
								<table border="0" cellspacing="0" cellpadding="0" width="400" id="onlineformTable">
									<tr>
										<td id="paddingFormPopup">
												<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'outputBody'))) echo htmlspecialchars($t->outputBody());?>												
										</td>
									</tr>
								</table>
						
							</td>
						</tr>
					</table>
					</div>
					</div>
					</td>
					<td valign="top" id="right"><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/framePopup05.gif" alt="" width="6" height="28" /></td>
				</tr>
				<tr>
					<td><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/framePopup08.gif" alt="" width="8" height="6" /></td>
					<td id="bottom"></td>
					<td><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/framePopup10.gif" alt="" width="6" height="6" /></td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
</body>
</html>
