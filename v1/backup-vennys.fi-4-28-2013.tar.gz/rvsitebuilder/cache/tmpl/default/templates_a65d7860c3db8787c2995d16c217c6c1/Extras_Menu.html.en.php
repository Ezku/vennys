<table width="100%" border="0" cellspacing="0" cellpadding="0" id="leftNavigator">
	<tr>
		<td><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","extras_pagetitle","sitebuilder"));?>" style="<?php echo htmlspecialchars($t->menuStylePageTitle);?>"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Title");?></a></td>
	</tr>
	<tr>
		<td><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","extras_metatag","sitebuilder"));?>" style="<?php echo htmlspecialchars($t->menuStyleMetaTag);?>"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Meta Tag");?></a></td>
	</tr>
	<tr>
		<td><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","extras_pageeffect","sitebuilder"));?>" style="<?php echo $t->menuStylePageEffect;?>"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Effect");?></a></td>
	</tr>
	<tr>
		<td><a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","extras_filename","sitebuilder"));?>" style="<?php echo $t->menuStyleFileName;?>"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("File Name");?></a></td>
	</tr>
</table>      
