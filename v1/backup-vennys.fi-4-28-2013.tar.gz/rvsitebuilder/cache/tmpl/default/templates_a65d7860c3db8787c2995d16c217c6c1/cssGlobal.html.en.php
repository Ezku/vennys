<!-- {addCssFile2(#ui.all.css#,theme,#sitebuilder#)}  -->
<link id ="linkcssglobal" rel="stylesheet" type="text/css" media="screen" href="<?php echo htmlspecialchars($t->webThemeUrl);?>/themes/default/sitebuilder/css/ui.all.css" />
