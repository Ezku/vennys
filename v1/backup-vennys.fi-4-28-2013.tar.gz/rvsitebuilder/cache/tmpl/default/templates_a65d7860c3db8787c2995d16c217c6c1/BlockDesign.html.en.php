<div class="tabBlocks">
	<div id="tabBlocks">
	   <ul>
	      <li><a href="#tabBlocks-1"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("single column");?></a></li>
	      <li><a href="#tabBlocks-2"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("multi columns");?></a></li>
	   </ul>
	   <div id="tabBlocks-1">
		   <div style="width:640px;height:205px;overflow: auto;">
		      <?php if ($this->options['strict'] || (is_array($t->aBlockDataSingle)  || is_object($t->aBlockDataSingle))) foreach($t->aBlockDataSingle as $kBlockDataSingle => $vBlockDataSingle) {?>
				<div style="float: left;">
		      		<input type ="hidden" id ="blockDataL<?php echo htmlspecialchars($vBlockDataSingle->rvs_block_id);?>" value ="<?php echo htmlspecialchars($vBlockDataSingle->block_data);?>" />
					<a href="javascript:void(0)" class="blocklayout minilayout " targetHide ="#blockDataL<?php echo htmlspecialchars($vBlockDataSingle->rvs_block_id);?>" />
						<img border="0" class="minilayout" src="<?php echo $vBlockDataSingle->block_images;?>" />
					</a>
				</div>
		      <?php }?>
		   </div>
	   	</div>
	
	   	<div id="tabBlocks-2">
	      	 <div style="width:640px;height:215px;overflow: auto;">
		      <?php if ($this->options['strict'] || (is_array($t->aBlockDataMulti)  || is_object($t->aBlockDataMulti))) foreach($t->aBlockDataMulti as $kBlockDataMulti => $vBlockDataMulti) {?>
				<div style="float: left;">
		      		<input type ="hidden" id ="blockDataL<?php echo htmlspecialchars($vBlockDataMulti->rvs_block_id);?>" value ="<?php echo htmlspecialchars($vBlockDataMulti->block_data);?>" />
					<a href="javascript:void(0)" class="blocklayout minilayout " targetHide ="#blockDataL<?php echo htmlspecialchars($vBlockDataMulti->rvs_block_id);?>" />
						<img border="0" class="minilayout" src="<?php echo $vBlockDataMulti->block_images;?>" />
					</a>
				</div>
		      <?php }?>
		   	</div>
		</div>
		
		<div align="right" style="padding-top:10px;">
	<input type ="hidden" id ="targetBlockDesign" value ="1" />
    <input type="button" class="btnSubmit" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("submit");?>" id="submitImageBlockDesign" />
		</div> 
	</div> 
</div>