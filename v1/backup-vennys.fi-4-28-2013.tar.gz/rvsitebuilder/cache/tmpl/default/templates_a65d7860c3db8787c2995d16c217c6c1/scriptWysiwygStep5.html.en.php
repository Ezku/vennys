<?php echo $t->scriptOpen;?>
stepWysi = true;
<?php if ($t->isWindowWysi)  {?>
    <?php echo htmlspecialchars($t->oLayoutJS);?>
	
if(document.all) {
	setTimeout(function(){
    jQuery.sitebuilder.wysiwyg.setDefaultWysiwygStep5('<?php echo htmlspecialchars($t->currentLayout);?>', '<?php echo htmlspecialchars($t->currentLayoutZone);?>',<?php echo htmlspecialchars($t->currentwidthLayout);?>);
	},250);
	}else {
	 jQuery.sitebuilder.wysiwyg.setDefaultWysiwygStep5('<?php echo htmlspecialchars($t->currentLayout);?>', '<?php echo htmlspecialchars($t->currentLayoutZone);?>',<?php echo htmlspecialchars($t->currentwidthLayout);?>);
	}
    fixedPositsionTop = 180;
<?php } else {?>
    fixedPositsionTop = 0;
<?php }?>
//global oPageParent use on page link navigator build on common
oPageParent = jQuery.sitebuilder.sitebuilder.getParentOpen('testWindowName',window.opener,'');
jQuery.sitebuilder.sitebuilder.returnToListPageStructure('<?php echo htmlspecialchars($t->isWindowName);?><?php echo htmlspecialchars($t->currentPageId);?>',this.window);
var wellcomNewWin = '<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Wellcome to this window"));?>';
var msgCurrentPage = '<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Active list page structure."));?>';

<?php echo $t->scriptClose;?>
