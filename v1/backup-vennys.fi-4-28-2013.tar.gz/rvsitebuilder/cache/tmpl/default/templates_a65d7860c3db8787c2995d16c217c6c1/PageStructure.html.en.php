 <!--form name="form1" method="post" FLEXY:IGNORE="yes"-->
<?php echo $t->scriptOpen;?>
//Page Structure Category
var pageList = new Array();
<?php if ($this->options['strict'] || (is_array($t->pageList)  || is_object($t->pageList))) foreach($t->pageList as $k1 => $v1) {?>
pageList[<?php echo htmlspecialchars($k1);?>] = new Array();
    <?php if ($this->options['strict'] || (is_array($v1)  || is_object($v1))) foreach($v1 as $k2 => $v2) {?>
    pageList[<?php echo htmlspecialchars($k1);?>][<?php echo htmlspecialchars($k2);?>] =  '<?php echo $v2;?>' ;
    <?php }?>  
<?php }?>

//Default User Page
var userPageName = {};
var userPageValue = {};
<?php if ($this->options['strict'] || (is_array($t->userPage)  || is_object($t->userPage))) foreach($t->userPage as $k => $v) {?>
userPageName['<?php echo htmlspecialchars($k);?>'] = '<?php echo $v->page_name;?>';
userPageValue['<?php echo htmlspecialchars($k);?>'] = '<?php echo $v->value;?>' ;
<?php }?>
msgSetCompoDB = {};
<?php if ($this->options['strict'] || (is_array($t->aComponentDB)  || is_object($t->aComponentDB))) foreach($t->aComponentDB as $k => $v) {?>
msgSetCompoDB['<?php echo htmlspecialchars($v);?>'] = '<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg",$v));?> <?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","database component already exists."));?>';
<?php }?>

msgTryoutTemplateExisit = {};
<?php if ($this->options['strict'] || (is_array($t->listTryout)  || is_object($t->listTryout))) foreach($t->listTryout as $k => $v) {?>
msgTryoutTemplateExisit['<?php echo htmlspecialchars($v['page_type']);?>'] = '<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg",$v['page_name']));?> <?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","database component already exists."));?>';
<?php }?>

// Message Translation
var lowerPageMsg            = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Sorry, there is a sub menu. Please delete the sub menu first."));?>";
var homePageMsg             = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","This page is Home Page and can not "));?>";
var upIsHomeMsg             = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Sorry, can not move up. The upper page is Home Page."));?>";
var invalidPageMsg          = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Empty page and page contain @ , ^ , and > is prohibited. Please "));?>";
var renameEmptyMsg      = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Empty page name is prohibited. Please rename again."));?>";
var addPageEmptyMsg     = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Empty page name is prohibited. Please add new page again."));?>";
var lowestPageMsg           = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","This is the sub menu."));?>";
var topPageMsg              = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","This is the top menu."));?>";
var normalBeforeMsg         = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Please add normal page before add extra component."));?>";
var pageListEmptyMsg    = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Page List is empty!"));?>";
var moveUpTxt               = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","move page up"));?>";
var moveDownTxt                 = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","move page down"));?>";
var toLowerTxt                  = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","change to sub menu"));?>";
var toUpperTxt                  = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","change to top menu"));?>";
var deleteTxt                   = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","delete"));?>";
var renamePageTxt           = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Rename page"));?>";
var addPageTxt              = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Add new page"));?>";
var againTxt                    = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","again"));?>";
var enterRename         = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Enter Page Name."));?>";
var msgInsertDataBase = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Please, set database config"));?>";
var statusConnectDB = '<?php echo htmlspecialchars($t->compoDBStatus);?>';
var msgWaitCreateDB = '<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Create database please wait.."));?>';
<?php echo $t->scriptClose;?>
 <!--END Javascript-->
 <div align="left" style="padding-left:20px;">
 <table width="880" border="0" cellspacing="0" cellpadding="0">
    <tr>
        <td id="paddingForm">
            <div id="formStructure">
            
				
				<!--  Disable compodb by tryout mode -->
            	<?php if (!$t->isTryoutMod)  {?>
				<div>                                                     
                 <!--  Message compoDB-->
                   <!-- {compoDBmsgBox:h} -->
                 <!-- end  Message compoDB -->
               </div>
	            <!-- Input Text Box add DBname & username & password -->	                                                
	               <?php if (!$t->compoDBStatus)  {?>
	                <br>
                   <!--   <a href="javascript:disPlayOnOff('checkComponentDB')" class="btnchangeDB">{translate(#change database#)}</a> -->
                   <?php }?>
                   <div style="<?php echo htmlspecialchars($t->compoDBOnOff);?>">
                   <!-- START:: Edit This Block in Template checkComponentDB.html -->
                   <!--   <flexy:include src="checkComponentDB.html" /> --> 
                   <!-- END:: Edit This Block in Template checkComponentDB.html -->
                   </div>
	              <?php }?>
	                           
	           <!-- End Input Text Box add DBname & username & password -->
				
           <div align="left">
           <br>
		   
		 	<form name="form1" method="post" action="PageStructure.php?<?php echo htmlspecialchars($t->sessID);?>" style="padding:0px; margin:0px;">
 				<div style="display:none"></div>   
                <span>&nbsp;<label for="default"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Default Page Structure");?> :</label></span>
				<span class="inlinehelp" onmouseover="this.className='inlinehelpOver';" onMouseOut="this.className='inlinehelp';"><img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" />
					<span style="margin:-130px 0 0 -10px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Page Structure");?></span>
				</span>
			</form> 
                </div>
                <div>
                    <table width="100%" border="0" cellspacing="5" cellpadding="0">
                        <tr>
                            <td width="45%" valign="top">
                                <table cellpadding="0" cellspacing="0" width="100%">
                                    <tr>
                                        <td colspan="2" align="left"><label for="suggest"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Our Suggestions");?> :</label></td>
                                    </tr>
                                    <tr>
                                        <td width="70%" align="left">
                                            <div id="divSelectPage" style="padding:5px 0 8px 0;">
                                            <form name="form2" method="post" style="padding:0px; margin:0px;">  
												<select name="selectPage" multiple id="selectPage" size="11" class="borderSelect" style="width:260px; height:300px;">
                      
                                                 <?php if ($this->options['strict'] || (is_array($t->aPageSugges)  || is_object($t->aPageSugges))) foreach($t->aPageSugges as $kaPageSugges => $vaPageSugges) {?>

                                                    <option value="<?php echo htmlspecialchars($vaPageSugges['value']);?>" img="<?php echo htmlspecialchars($vaPageSugges['images']);?>" desc="<?php echo htmlspecialchars($vaPageSugges['descrip']);?>"><?php echo htmlspecialchars($vaPageSugges['text']);?></option>
                                                    <?php }?>
                                                </select>         
                                            </form> 
                                            </div>
                                        </td>
                                        <td width="30%" align="left">
                                            <table width="100%" border="0" cellspacing="5" cellpadding="0" class="imglink-addpage step4_btnmenu" onmouseover="this.style.cursor='pointer';">
                                                <tr>
                                                    <td align="center" class="pagestrucLink">
                                                    <div href="javascript:void(0);" id ='btnMove' class="btnMovepage"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move");?></div></td>
												</tr>
												<tr>
													<td align="center" id="divAddID" isDisable="true" class="pagestrucLink imglink-addcomponent">				
														<div href="javascript:void(0);" id="addCompoId" class="btnAddCompo" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Add Extra Component"));?>"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Add");?></div>										
													</td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td colspan="2" align="left">
                                            <!-- components DB -->
                                            <div>
	                                                <form name="form3" method="post" action="" style="padding:0px; margin:0px;">
	                                                <div><label for="extra"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Component");?> :</label></div>
	                                                <div class="padding" div style="float:left;">
	                                              
	                                                    <select name="select" size="11" id="select" class="borderSelect" style="width:260px; height:180px;">
	                                                    <optgroup label="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Component use File"));?>">
	                                         
	                                                    <?php if ($this->options['strict'] || (is_array($t->listComponent)  || is_object($t->listComponent))) foreach($t->listComponent as $k => $v) {?>
	                    
	                                                                    <option value="<?php echo htmlspecialchars($k);?>"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate($v);?>
																		<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("isPhotoAlbumDeprecated",$k));?></option>
	                                                    <?php }?>
	                                                    </optgroup>
	                                                   <!-- Extra Components DB -->
	                                                    	<?php if ($t->aComponentDBFinal)  {?>
	                                                    		<optgroup label="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Component use Database"));?>">
	                                                    			
	                                                       		<?php if ($this->options['strict'] || (is_array($t->aComponentDBFinal)  || is_object($t->aComponentDBFinal))) foreach($t->aComponentDBFinal as $k => $v) {?>
																		<?php if ($v['multiple'])  {?>
																		              <option value="<?php echo htmlspecialchars($k);?>" mutiplecompo="db"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate($v['name']);?></option>                                                              
																		 <?php } else {?>
																		 <!-- ปรับ faq ให้เป็น ตัวใหญ่ :: nipaporn  11/03/2011 -->
																		           <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isEqual'))) if ($t->isEqual($v['name'],"Faq")) { ?>
                                                                                  <option value="<?php echo htmlspecialchars($k);?>" compo="db"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("FAQ");?></option>
                                                                                   <?php } else {?>
                                                                                 <option value="<?php echo htmlspecialchars($k);?>" compo="db"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate($v['name']);?></option>
                                                                                   <?php }?>
																		 <?php }?>
																		   
	                                                       		<?php }?>
	                                                       		</optgroup>
	                                                    	<?php }?>
	                                                   <!--end Extra Components DB -->
	                                                   
	                                                   <!-- List Tryout -->
	                                                
	                                                   <?php if ($t->useTryout)  {?>
	                                                 
	                                                    <optgroup label="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Tryout Page"));?>">
	                                                        <?php if ($this->options['strict'] || (is_array($t->listTryout)  || is_object($t->listTryout))) foreach($t->listTryout as $k => $v) {?>
	                        
	                                                                        <option value="<?php echo htmlspecialchars($v['component_name']);?>" pageExit ="<?php echo htmlspecialchars($v['page_type']);?>"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate($v['page_name']);?></option>
	                                                        <?php }?>
                                                        </optgroup>
                                                        <?php }?>
	                                                   <!--  End List Tryout -->
	                                                    </select>                                            
	                                                </div>
                                                   <!--    
													<div  id="divAddID"  style="float:right; padding-right:20px; padding-top:20px; cursor:pointer;"  isDisable="true"  class="pagestrucLink imglink-addcomponent">
														<a href="javascript:void(0);"  id="addCompoId" class="btnAddCompo" title="{translate(#Add Extra Component#)}" ><div  style="margin-top:10px;">{translate(#Add#):h}</div></a></a>
													</div>
													<div style="clear:both;"></div>
													-->  
	                                                </form>	                                               

                                            </div>
                                            <!-- end components DB -->
                                        </td>
                                    </tr>
                                </table>
                            </td>

                            <td width="55%" valign="top">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td colspan="2" align="left">
                                        <div>
                                            <span><label for="select"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Your Selection");?></label></span>
                                            <span class="f10b_green" style="display:none">(<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("HTML tag allowed.");?>)</span>
                                        </div>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="45%" valign="top">
                                        <div style="padding:5px 0 8px 0;">
                                        <form name="form4" id="form4" method="post" action="" onsubmit="return CheckNoneList()" style="padding:0px; margin:0px;">
											<select name="pageSet[]" multiple="multiple" id="pageSet" style="width:250px; height:300px;" class="borderSelect">
                                              <?php if ($this->options['strict'] || (is_array($t->userPage2)  || is_object($t->userPage2))) foreach($t->userPage2 as $k => $v) {?>
                                      
                                                  <option value="<?php echo htmlspecialchars($v->value);?>"><?php echo htmlspecialchars($v->page_name);?></option>
                                              <?php }?>
                                            </select>
                                        
                                        </div>
                                        </td>
                                        <td rowspan="2" valign="top" width="55%" align="left">
                                            <table width="100%" border="0" cellspacing="8" cellpadding="0" class="step4_btnmenu">
                                                <tr>
                                                    <td valign ="middle"><div href ="javascript:void(0);" id='moveupId' class="btnMoveupDis" isDisable="true"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move Up");?></div></td>
													<td>&nbsp;</td>
                                                </tr>
                                                <tr>
                                                   <td valign ="middle"><div href ="javascript:void(0);" id='movedownId' class ="btnMovedownDis" isDisable="true"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move Down");?></div></td>
												   <td>&nbsp;</td>
                                                </tr>
                                                <tr>
                                                   <td nowrap ="nowrap" valign ="middle"><div href ="javascript:void(0);" id='submenuId' class ="btnSubmenuDis" isDisable="true"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Lower Level");?></div>
                                                   </td>
												   <td align="left">
												   		<span class="inlinehelp" onmouseover="this.className='inlinehelpOver';" onMouseOut="this.className='inlinehelp';"><img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="texttop" />
															<span style="margin:-240px 0 0 -210px"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Sub Menu","vprintf","SB_IMG_URL|SB_IMG_URL");?></span>  
														</span>
													</td>
                                                </tr>
                                                <tr>
                                                    <td nowrap="nowrap" valign="middle"><div href ="javascript:void(0);" id='topmenuId' class ="btnTopmenuDis" isDisable="true"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upper Level");?></div>
                                                                                                    
                                                    </td>
													<td align="left">
														<span class="inlinehelp" onmouseover="this.className='inlinehelpOver';" onMouseOut="this.className='inlinehelp';"> <img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="texttop" />
															<span style="margin:-162px 0 0 -210px"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Top Menu");?></span>
														</span> 
													</td>
                                                </tr>
                                                <tr>
                                                    <td valign="middle">     
                                                      <div href="javascript:void(0);" id ='btnRenameId' class ="btnRename">
                                                        <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename");?> </div>
                                                    </td>
													<td>&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td valign="middle">
                                                    <div href="javascript:void(0);" id ='btnDeleteId' class="btnDeleteDis" isDisable="true">
                                                    <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Delete");?></div></td>
													<td>&nbsp;</td>
                                                </tr>

                                                <tr>
                                                    <td valign="middle"><div href="javascript:void(0);" id='bntAddpageId' class ="btnAddpage" isDisable="true"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Add New Page");?></div></td>
													<td>&nbsp;</td>
                                                </tr>
                                                
                                            </table>
                                     
											<div style="padding-left:5px; margin-top:20px;">
												<div style="float:left;"><input type="checkbox" name="no_layout" value="1" <?php echo htmlspecialchars($t->isNoLayout);?> id="no_layout" />
												</div>
												<div style="padding:3px 5px 2px 0; float:left; color:#D2270B; font-weight:normal;">
													<label for="no_layout"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("No Layout Template");?></label>
												</div>
												<div>
													<span class="inlinehelp" onmouseover="this.className='inlinehelpOverleft';" onMouseOut="this.className='inlinehelp';"><img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" />
													<span style="margin:5px 0 0 -400px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help No layout");?></span>
													</span>
												</div>
											</div>
											<div class="clearit"></div>
											<div style="margin-left:8px; margin-top:10px; padding-bottom:0px;">
												<input type="submit" name="Submit" value=" <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>" onclick="SelectAll(); Javascript:bSubmitted=true;" class="btnSave" />
												<input type="button" name="resett" value=" <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Reset");?>" onclick="_reset();" class="btnReset" />
											</div>
                                        </td>
                                    </tr>
								   	<tr>
								   	 
									   <td colspan="2" align="left"> 
									      <div id="DisplayPageName"><?php echo htmlspecialchars($t->currentPageName);?></div>
										  <div id="DisplayDsc"><?php echo htmlspecialchars($t->currentSuggetDesc);?></div>
									   </td>
								  	</tr> 
									<tr>
									   <td colspan="2" align="left" style="padding-top:10px; padding-bottom:4px; color:#686868;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("preview");?></td>
								 	</tr>
								   	<tr>
									   <td colspan="2" align="left" style="display:block;height:200px;width:263px;">
											<img id="DisplayImg" border="0" style="padding:3px;" width="263px" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/layoutwysiwyg/<?php echo htmlspecialchars($t->currentSuggetImage);?>" />
									   </td>
								 	</tr> 
                                </table>
                            </td>
                        </tr>
                    </table>

                </div>
            </div>
        </td>
        </form>
    </tr>
</table>
</div>
		<?php if ($t->isPro)  {?>
<!--  Disable compodb by tryout mode -->
            	<?php if (!$t->isTryoutMod)  {?>
				<div style="padding-left:35px;"><a name="dbcomponent"></a>                                       
                 <!--  Message compoDB-->
                   <!-- {compoDBmsgBox:h} -->
                 <!-- end  Message compoDB -->
               </div>
	            <!-- Input Text Box add DBname & username & password -->	               
                <form name="FrmDBConfig" id="FrmDBConfig" method="post" action="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","createdbforcomponent","sitebuilder"));?>">
			   <div style="margin-left:35px;  padding-bottom:15px;">
			        <input type="hidden" name="action" value="" />
			        <input type="hidden" name="openDBPopup" value="1" />
	               <?php if (!$t->compoDBStatus)  {?>
	               <input type="hidden" name="loadFrmAction" value="viewcreatedbconfig" />
                    <br />
                        <input name="submitdbconfig" type="button" id="submitImport" value=" <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("crerate database");?>" class="btnRestore" />

                   <?php } else {?>
                   <input type="hidden" name="loadFrmAction" value="vieweditdbconfig" />
                    <br />    
                        <input name="submitdbconfig" type="button" id="submitdbconfig" value=" <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("change database");?>" class="btnRestore" />
                   <?php }?>
                        
				  </div>
				  </form>
	              <?php }?>
	         <?php }?>     
	                           
	           <!-- End Input Text Box add DBname & username & password -->
            </div>
<div id="log"></div>

<!--Start Dialog Alert Msg -->


<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/PageStructure.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>



<!-- 
<div id ='layouttemplate-select' style='display:none'>
<flexy:include src="LayoutTemplateMain.html" />
</div>
 -->
 
<!--End Dialog Alert Msg -->

