<?php echo $t->scriptOpen;?>

		window.name = "testWindowName";
        <?php if ($this->options['strict'] || (is_array($t->aPageStructureData)  || is_object($t->aPageStructureData))) foreach($t->aPageStructureData as $k => $v) {?>
	    var newwin<?php echo htmlspecialchars($v->project_page_id);?> = false;

		<?php }?>
	
<?php echo $t->scriptClose;?>

			<!-- <div class="frameTable"> 
				<div class="border">
					<div class="tableStep5" > 
			-->
			
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="mainTable mainBorder" id="tblInternalPage">						
					<?php if ($t->internalsetup)  {?>
						<tr>
							<td class="headIn" width="40%"><div align="left"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Internal Page");?></div></td>
							<td class="headIn" width="10%"><div style="color:#4F4F4F">External Link<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="1" /></div></td>
							<td class="headIn" width="10%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit");?><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="1" /></td>
							<td class="headIn" width="10%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("HTML Code");?><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="1" /></td>
							<td class="headIn" width="10%" valign="top"><div style="color:#4F4F4F">Link Target<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="16" height="1" alt="" /></div></td>
							<td class="headIn" width="10%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Last Modified");?></td>
							<td class="headIn" width="10%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Delete");?></td>
						</tr>
						<!-- {aInternalPageStructureData:r} -->
						<?php if ($this->options['strict'] || (is_array($t->aInternalPageStructureData)  || is_object($t->aInternalPageStructureData))) foreach($t->aInternalPageStructureData as $k => $v) {?>
						<tr id="tr_<?php echo htmlspecialchars($v->project_page_id);?>" class="internalPage" setSelectValue ="<?php echo htmlspecialchars($v->project_page_id);?>" setPAgeName ="<?php echo htmlspecialchars($v->page_name);?>">
							<td class="<?php echo htmlspecialchars($v->classTDTop);?>" align="left" width="40%"><div class="main"><?php echo $v->page_name;?></div></td>
													
							<td class="<?php echo htmlspecialchars($v->classTD2);?>" width="10%">&nbsp;</td>
							
							<td class="<?php echo htmlspecialchars($v->classTDMid);?>" width="10%">
							<?php if ($v->compo)  {?>
							 <a href="javascript:" class="jq_CompoLink" component_name ="<?php echo htmlspecialchars($v->component_name);?>" project_page_id ="<?php echo htmlspecialchars($v->component_name);?>DefaultPageID = '<?php echo htmlspecialchars($v->project_page_id);?>'" targetact ="rvDisplayMain">
                                        <img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/i-manage.gif" width="17" height="15" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Manage"));?>" border="0" /></a>
							</td>
							<td>
								</td>
							<?php } else {?>
								<a href="<?php echo $t->sgl_path_url;?>/<?php echo htmlspecialchars($t->index_phpsu);?>/sitebuilder/wysiwyg/project_page_id/<?php echo htmlspecialchars($v->project_page_id);?>" target ="windowsName<?php echo htmlspecialchars($v->project_page_id);?>" onclick="return jQuery.sitebuilder.sitebuilder.switchNewWin('newwin<?php echo htmlspecialchars($v->project_page_id);?>');">
               					<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/i-edit.gif" width="52" height="20" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Edit"));?>" border="0" /></a>
							

							</td>
							
							<td class="<?php echo htmlspecialchars($v->classTDMid);?>" width="10%">
								<a href="<?php echo $t->sgl_path_url;?>/<?php echo htmlspecialchars($t->index_phpsu);?>/sitebuilder/wysiwyg/project_page_id/<?php echo $v->project_page_id;?>/htmlcode/1">
								<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/htmlcode.gif" width="30" height="20" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Edit"));?>" border="0" /></a>
							</td>
						<?php }?>
							<td class="<?php echo htmlspecialchars($v->classTDMid);?>" width="10%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
							<td class="<?php echo htmlspecialchars($v->classTDMid);?> txt10n" width="10%">
							<?php if ($v->last_modifier)  {?>
								<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("getFormatTime",$v->last_modifier));?>
								<?php } else {?>
								.....
								<?php }?>
							</td>
						   <td class="<?php echo htmlspecialchars($v->classTDMid);?>" width="10%">
						   <a class ="jq_DeleteListPage" pagename ="<?php echo htmlspecialchars($v->page_name);?>" project_page_id ="<?php echo htmlspecialchars($v->project_page_id);?>">	
              					 	   <img class="SPicon SPdel_wys" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="19" height="18" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Delete"));?>" style="cursor:pointer" border="0" />
              					 		
              			  </a>	
						  </td>							
						</tr>
						<?php }?>
				<?php }?>
					</table>
		<!-- 		</div>
				</div>
			</div>
		-->
<?php if ($t->actionAdd)  {?>
<div style ="display:none"> 
<scp>
document.getElementById('rvDisplayMsgUserComponent').innerHTML='<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'msgGet'))) echo $t->msgGet();?>';
Effect.Pulsate('rvDisplayMsgUserComponent');
document.getElementById('rvDisplayErrorUserComponent').innerHTML='
<?php if ($t->error)  {?>
<table border="0" cellspacing="0" cellpadding="0" class="errorStep2" align="center">
									<tr><td><ul>
											<?php if ($this->options['strict'] || (is_array($t->error)  || is_object($t->error))) foreach($t->error as $k => $v) {?>
												<li><?php echo $v;?></li>
											<?php }?>
									</ul></td></tr>
								</table>';
Effect.Pulsate('rvDisplayErrorUserComponent');
document.getElementById('page_name').focus();
<?php } else {?>';
document.getElementById('page_name').value='';
<?php }?>
</scp>
</div>
<?php }?>