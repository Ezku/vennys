 <?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('ImportTemplateMenu.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>    
 <table align="center">
	<tr>
		<td>
		<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'msgGet'))) if ($t->msgGet()) { ?><span><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'msgGet'))) echo $t->msgGet();?></span><?php }?>
		<?php if ($t->isImportComplete)  {?>
			<a href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","sitebuilder","sitebuilder"));?>" class="templatelink"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Click here");?></a>
		<?php }?>
		<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if ($t->isAdmin()) { ?>
			<?php if ($t->error)  {?>
				<?php if ($this->options['strict'] || (is_array($t->error)  || is_object($t->error))) foreach($t->error as $k => $v) {?>
				<div class="error" style="margin-left: 50px;"><li><?php echo $v;?></li></div>
				<?php }?>
			<?php }?>
		<?php }?>
		</td>
	</tr>
</table>

<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if (!$t->isAdmin()) { ?>
<form name="FrmUpload" action="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","uploadtemplate","sitebuilder"));?>" method="post" enctype="multipart/form-data">
<?php } else {?>
<form name="FrmUpload" action="" method="post" enctype="multipart/form-data">
<?php }?>
<table align="center" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td valign="top" class="table02">
		<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if ($t->isAdmin()) { ?>
		<!-- table class="fonttopic" width="100%">
			<tr>
				<td align="center">
				{if:parent}
					{translate(#Upload Parent Template#):h}
				{else:}
					{translate(#Upload Child Template#):h}
				{end:}
				</td>
			</tr>
		</table-->
		<?php }?>
		
		<table align="center" width="100%" border="0" cellspacing="0" cellpadding="0">
	<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if ($t->isAdmin()) { ?>
		<?php if ($t->parent)  {?>
			<?php if ($t->RVSiteBuilderPro)  {?>
			<tr class="textinside">
				<td width="19%"></td>
				<td width="81%">
				<?php if ($t->rvsitebuilderPro)  {?>
					<input class="bclear" id="rvsitebuilderPro" value="1" name="rvsitebuilderPro" type="checkbox" checked="checked"> 
				<?php } else {?>
					<input class="bclear" id="rvsitebuilderPro" value="1" name="rvsitebuilderPro" type="checkbox"> 
				<?php }?>
					Template RvSiteBuilder Pro 
				</td>
			</tr>
			<?php } else {?>
				<input id="rvsitebuilderPro" value="" name="rvsitebuilderPro" type="hidden">
			<?php }?>
		<?php } else {?>
			<tr class="textinside">
				<td width="19%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Parent");?></td>
				<td width="81%">
				<select name="parent_template_id">
					<option value=""><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("select parent template");?></option>
					<?php echo $t->aParentTemplateOptions;?>
				</select>
				</td>
			</tr>
		<?php }?>
	<?php }?>

			<tr>
			<td colspan="2" id="formImport">
					<!-- Inline don't show admin area -->
					<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if (!$t->isAdmin()) { ?>
					<div style="padding-bottom: 10px" class="f12b_blue"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import template system");?>
					   <span class="inlinehelp" onmouseover="this.className='inlinehelpOver';" onMouseOut="this.className='inlinehelp';"> <img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webThemeUrl);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" />
						  <span style="margin:-30px 10px 10px 10px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Import Template");?></span>
				        </span>
				    </div>
				    <?php }?>
			  	<div style="padding:8px 100px 8px 10px;"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Help Template");?></b></div>
				<div style="padding-left: 10px;">
					<input value="upload" name="action" type="hidden" />
					<span>
						<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if ($t->isAdmin()) { ?>
							<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import Parent Template");?>
						<?php } else {?>
							<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import Template");?>
						<?php }?>					
					</span>
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isDirectAdminMode'))) if ($t->isDirectAdminMode()) { ?>
				<input type="button" id="uploadTemplate" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upload");?>" class="uploadTemplate">
					<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if (!$t->isAdmin()) { ?>
				   <input type="hidden" name="imagePathReady" id="imagePathReady" value="" />
				    <input type="hidden" name="submitUpload" id="step2" value="1" />
					<input type="hidden" name="submitUploadGoToStep3" id="step3" value="0" />
					<input type="hidden" name="current_template_item_id" value="<?php echo htmlspecialchars($t->current_template_item_id);?>" />
	                <input type="hidden" name="current_template_id" value="<?php echo htmlspecialchars($t->current_template_id);?>" />
					<?php } else {?>
					<input type="hidden" name="submitUpload" id="step2" value="1" />
					<input type="hidden" name="imagePathReady" id="imagePathReady" value="" />
					<?php }?>
				<?php } else {?>
				<span><input name="fileUpload" type="file" class="btnBrowse" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Browse");?>" /></span>
			</div>
				<div style="padding-left: 10px">
					<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if (!$t->isAdmin()) { ?>
					<input name="submitUpload" type="submit" class="btnImportGoStep2" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import and go to template catalogue");?>" onclick="Javascript:bSubmitted=true;" />
						
						<?php if ($t->reupload)  {?>
							<input type="hidden" name="reupload" value="1" />
						<?php }?>
						
					<input type="hidden" name="current_template_item_id" value="<?php echo htmlspecialchars($t->current_template_item_id);?>" />
					<input type="hidden" name="current_template_id" value="<?php echo htmlspecialchars($t->current_template_id);?>" />
					<input type="submit" class="btnImportGoStep3" name="submitUploadGoToStep3" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import and go to step 3");?>" onclick="Javascript:bSubmitted=true;">
					<?php } else {?>
					<input name="submitUpload" type="submit" class="btnUpload" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import");?>" onclick="Javascript:bSubmitted=true;" />
				</div>
					<?php }?>
				<?php }?>	
					<!-- Inline don't show admin area -->
			</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</form>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/UploadTemplate.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
