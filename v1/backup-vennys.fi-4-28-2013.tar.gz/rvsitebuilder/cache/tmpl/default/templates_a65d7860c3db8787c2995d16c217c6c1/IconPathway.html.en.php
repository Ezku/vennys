<script type="text/javascript">
function showMailSetup(){
	document.getElementById("email").style.visibility = "visible";
	document.getElementById("email").style.position = "";
}
function hideMailSetup(){
	document.getElementById("email").style.visibility = "hidden";
	document.getElementById("email").style.position = "absolute";
}
</script>

<form name="frmIconPathway" method="post" action="">
<div id="setPathway">
	<div id="effect">
		<span class="title"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Effect on:");?> :</span>
		<span><?php echo $t->option[0];?></span>
		<span><?php echo $t->option[1];?></span>
	</div>
	<div id="pathway">
		<span class="title"><img class="SPicon SPpwbe" src="<?php echo htmlspecialchars($t->icon_path);?>/spacer.gif" alt="" width="22" height="22" /><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Pathway");?> :</span>	
		<span><label for="show"><?php echo $t->icon['pathway'][1];?></label></span>
		<span><label for="hide"><?php echo $t->icon['pathway'][0];?></label></span>
	</div>
	<div style="height:5px;"></div>
	<div id="setIcon">
		<table width="95%" border="0" cellspacing="0" cellpadding="0">
			<tr class="header">
				<td width="34%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Email A Page To A Friend");?></td>
				<td width="33%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Print this page");?></td>
				<td width="33%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Add to Favorite");?></td>
			</tr>
			<tr>
				<td>
					<div class="icon">
						<img class="SPicon SPpfbe" src="<?php echo htmlspecialchars($t->icon_path);?>/spacer.gif" alt="" width="22" height="22" />					
					</div>
					<div class="radio">
						<div onclick="showMailSetup()"><?php echo $t->icon['mail'][1];?></div>
						<div onclick="hideMailSetup()"><?php echo $t->icon['mail'][0];?></div>
					</div>
				</td>
				<td>
					<div class="icon">
						<img class="SPicon SPppbe" src="<?php echo htmlspecialchars($t->icon_path);?>/spacer.gif" alt="" width="22" height="22" />				
					</div>
					<div class="radio">
						<div><?php echo $t->icon['print'][1];?></div>
						<div><?php echo $t->icon['print'][0];?></div>
					</div>
				</td>
				<td>
					<div class="icon">
						<img class="SPicon SPafbe" src="<?php echo htmlspecialchars($t->icon_path);?>/spacer.gif" alt="" width="22" height="22" />				
					</div>
					<div class="radio">
						<div><?php echo $t->icon['favorite'][1];?></div>
						<div><?php echo $t->icon['favorite'][0];?></div>
					</div>
				</td>
			</tr>
		</table>
	</div>
	<div style="height:5px;"></div>
	<div id="email" style="<?php echo $t->MailStyle;?>">
		<div class="titleEmail"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Email A Page To A Friend Setting");?></div>
		<div class="title">
		  <label for="subject"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Subject");?> : </label>
		  <input name="subject" type="text" id="subject" value="<?php echo $t->subject;?>" style="width:350px;" />
		</div>
		<div class="title"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Body");?> : </div>
		<div><textarea name="body" cols="55" rows="7" style="width:350px;"><?php echo $t->body;?></textarea></div>
		<div class="title"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Email Variable:");?> :</div>
		<div style="padding-left:15px">
			<div>%page.title = <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Title");?></div>
			<div>%page.url = <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page URL");?></div>
		</div>
	</div>
	<div class="locationButton">
		<input type ="hidden" name ="action" value ="edit">
		<div><input class="btnSave" type="submit" name="submit" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>" onclick="Javascript:bSubmitted=true;" /></div>
		<div><input class="btnCancel" type="submit" name="cancel" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>" onclick="Javascript:bSubmitted = true;window.close()" /></div>
	</div>
</div>
</form>