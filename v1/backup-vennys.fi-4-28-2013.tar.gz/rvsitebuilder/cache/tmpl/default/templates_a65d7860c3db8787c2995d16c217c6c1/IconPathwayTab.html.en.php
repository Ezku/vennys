<div id="selectIcon"> 
	<table cellspacing="0" cellpadding="2">
		<tr class="mainIcon">
			<td nowrap="nowrap" style="padding-top:15px;" class="noneGroup">
				<form method="post" id ="frmIconGroup" name="frmIconGroup" action="">
					<input type ="hidden" name="rvsMgr" value="ListPageStructure">
               	 	<input type ="hidden" name="rvsAct" value="edit">
				</form>
				
				<input type="checkbox" name="pathway" value="1" class="setIcomGroup" targetId ="pathwayIcon" <?php echo htmlspecialchars($t->isPathway);?>>
				<label for="pathway">
					<img class="SPicon SPpwbe" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="22" height="22" alt="" id="pathwayIcon" />
					<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Pathway");?>
				</label>
				<span>
					<span class="inlinehelp"> <img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" />
						<span style="margin:-150px 0 0 -10px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Pathway Icon","vprintf","SB_IMG_URL|SB_IMG_URL");?></span>
					</span>
				</span>
			</td>
			<td align="left" valign="top">
				<fieldset class="subIcon">
					<legend><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Icon Group");?></legend>
					<table border="0" cellspacing="0" cellpadding="0">
						<tr id="iconSetup">
							<td>
								<input type="checkbox" name="print" id="print" value="1" <?php echo htmlspecialchars($t->isPrint);?> class="setIcomGroup" targetId ="printIcon" />
								<label for="print">
									<img class="SPicon SPppbe" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="22" height="22" name="printIcon" id="printIcon" />	
									<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Print this page");?>								</label>
							</td>
							<td class="middle">
								<input type="checkbox" name="mail" id="mail" value="1" <?php echo htmlspecialchars($t->isMailToFriend);?> class="setIcomGroup" targetId ="mailIcon" />
								<label for="mail">
									<img class="SPicon SPpfbe" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="22" height="22" id="mailIcon" />
									<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Email A Page To A Friend");?>
								</label>
							</td>
							<td class="right">
								<input type="checkbox" name="favorite" id="favorite" value="1" <?php echo htmlspecialchars($t->isFavorite);?> class="setIcomGroup" targetId ="favoriteIcon" />							
								<label for="favorite">
									<img class="SPicon SPafbe" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="22" height="22" id="favoriteIcon" />
									<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Add to Favorite");?>
								</label>
							</td>
						</tr>
					</table>
				</fieldset>
			</td>
		</tr>
		<!-- Validate display login blog -->
         <?php if ($t->isComponentUseDB)  {?>
		<tr class="mainIcon">
			<td valign="top" align="left" colspan="2">
                    <fieldset class="subIcon">
                        <legend><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Display login block");?></legend>
						<?php echo $this->elements['chkBlogLogin']->toHtml();?>
						<label for="chkBlogLogin"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Display login block. You still be able to login","vprintf","UrlBlockLogin|urlBlogLogin");?></label>
                    </fieldset>
            </td>
        </tr>
		<?php }?>
	</table>
</div>
