<form action="" name="frmComponentFormOnline" id="frmComponentFormOnline" method="post">
	<input type="hidden" name="rvsMgr" value="FormOnline" /> 
	<input type="hidden" name="rvsAct" value="view" /> 
	<input type="hidden" name="isWysiwyg" id="isWysiwyg" value="<?php echo htmlspecialchars($t->isWysiwyg);?>" />
</form>
<div id ="mainDispaly"></div>
