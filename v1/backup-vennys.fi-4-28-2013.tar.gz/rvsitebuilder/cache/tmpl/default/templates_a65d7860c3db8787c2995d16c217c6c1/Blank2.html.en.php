<html>
<head>
<title><?php echo $t->pageTitle;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo htmlspecialchars($t->charset);?>">
<meta http-equiv="Content-Language" content="<?php echo htmlspecialchars($t->currLang);?>" />

<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'outputBody'))) echo htmlspecialchars($t->outputBody());?>
