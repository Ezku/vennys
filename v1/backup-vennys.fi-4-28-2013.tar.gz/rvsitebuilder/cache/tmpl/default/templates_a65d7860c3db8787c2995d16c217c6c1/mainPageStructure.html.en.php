		<div style="padding:3px;">
			<div>
				<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('IconPathwayTab.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
			</div>
			<div class="clear"><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="1" height="10" /></div>	
			
			<div class="txtPathway"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Navigator");?></div>
			<div class="bdrPathway">
				<input type="button" id="movePage" name ="movePage" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Move Page"));?>" class="btnpathway noneBorder" />
			</div>	
			<div class="clear"></div>	 
			<!-- Start List Master Page -->
			<div id="masterpage">
				  <?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('ListMasterPage.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?> 
				<!-- Start List Internal Page -->
			<!--<br />	
			<div class="tablename">{translate(#Internal Page#):h}</div>-->

			<!--End List Internal Page -->
			</div>
			<div id ="displayInternalPage">
						<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('ListInternalPage.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
			
			</div>
			<!-- End List Master Page -->
		</div>
			
			