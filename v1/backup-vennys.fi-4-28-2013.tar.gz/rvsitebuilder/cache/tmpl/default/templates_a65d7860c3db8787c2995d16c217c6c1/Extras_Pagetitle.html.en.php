<table cellspacing="0" cellpadding="0" width="100%">
 	<tr>
		<td id="paddingForm">
			<div class="tablename" style="padding-bottom:4px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Title");?>
			<span class="inlinehelp" onmouseover="this.className='inlinehelpOver';" onMouseOut="this.className='inlinehelp';"> <img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" />
				<span style="margin:-12px 0 0 8px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Page Title","vprintf","SB_IMG_URL|SB_IMG_URL");?>
</span>
		</span>
			</div>

			<div class="frameTable">
				<div class="border">
					<table width="100%" border="0" cellspacing="6" cellpadding="0" class="tableInfo">
						<tr>
							<td width="26%" valign="top">
								<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('Extras_Menu.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
							</td>
							<td width="74%" valign="top">
								<div>
									<table width="100%" border="0" cellspacing="0" cellpadding="0">
										<tr class="header">
											<td width="30%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Name");?></td>

											<td width="50%"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Title");?></td>
											<td width="10%"><div align="center"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit");?></div></td>
											<td width="10%"><div align="center"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Reset");?></div></td>
										</tr>
									</table>
								</div>
								<div class="listPage">
									<table width="100%" border="0" cellspacing="0" cellpadding="0" class="manage">
									<?php if ($this->options['strict'] || (is_array($t->aPageStructureData)  || is_object($t->aPageStructureData))) foreach($t->aPageStructureData as $k => $v) {?>
									   <form id="pagetitleName_<?php echo htmlspecialchars($v->project_page_id);?>" name="pagetitleName" method="post" action="">
									    <?php if ($v->page_status)  {?> 
										<tr>
											<?php if ($v->parent_project_page_id)  {?>
                                             	<!-- Sub page -->
                                            <td width="30%" class="middleNamePage" align="left"><div class="sub" id="titlePageName_<?php echo htmlspecialchars($v->project_page_id);?>"><?php echo htmlspecialchars($v->page_name);?></div></td>
                                            <?php } else {?>                                             	
                                             	<?php if ($v->isMasterPage)  {?>
                                             	<!-- Master page -->
                                            	<td width="30%" class="middleNamePage" align="left"><div class="master" id="titlePageName_<?php echo htmlspecialchars($v->project_page_id);?>"><?php echo htmlspecialchars($v->page_name);?></div></td>
                                             	<?php } else {?>
                                             	<!-- Main page -->
                                            	<td width="30%" class="topNamePage" align="left"><div class="main" id="titlePageName_<?php echo htmlspecialchars($v->project_page_id);?>"><?php echo htmlspecialchars($v->page_name);?></div></td>
                                             	<?php }?>
                                           <?php }?>
											<td width="50%" align="left"><div id="mainpage_title_<?php echo htmlspecialchars($v->project_page_id);?>"><?php if ($v->page_title)  {?> <?php echo htmlspecialchars($v->page_title);?><?php }?></div></td>
											<td width="10%">
												<div align="center">
												<img onmouseover="this.style.cursor='pointer'" class="SPicon SPs6_edit editPageTitle" project_page_id ="<?php echo htmlspecialchars($v->project_page_id);?>" id ="btn_<?php echo htmlspecialchars($v->project_page_id);?>" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="21" height="21" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Edit"));?>" border="0">
												</div>
                                            </td>
											<td width="10%">
												<div align="center">
												<!-- Reset Page Title -->
                                            	<img id="btnResetPageTitle<?php echo htmlspecialchars($v->project_page_id);?>" onmouseover="this.style.cursor='pointer'" class="SPicon SPs6_reset resetPageTitle" project_page_id ="<?php echo htmlspecialchars($v->project_page_id);?>" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="21" height="21" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Reset"));?>" border="0">  
                                           		<!-- End Reset Page Title -->
												</div>
                                           </td>
										</tr>
										
										<?php } else {?>
										    <tr><td colspan="5">&nbsp;</td></tr>
										<?php }?>
										</form>
									<?php }?>
									</table>
								</div>
							</td>
						</tr>
					</table>
				</div>
			</div>
		</td>

	</tr>
</table>

<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/Extras_PagetitleEdit.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/Extras_PagetitleReset.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>

<div id="ConfirmDelete" style="display:none"><?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('ConfirmDelete.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?></div>