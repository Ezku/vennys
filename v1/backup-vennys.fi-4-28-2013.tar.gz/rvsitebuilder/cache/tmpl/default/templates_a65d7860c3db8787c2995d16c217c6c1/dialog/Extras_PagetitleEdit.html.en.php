<div id="extraPagetitle" style="display: none;">
    <div id="extraPagetitle-edit" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Change Page Title Name");?>">
        <div class="dialog-option">
modal: true,
closeOnEscape :true,
width: 500,
buttons:{
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>": function() {
        jQuery.sitebuilder.extras_Pagetitle.cmdSave("#form1");
    },
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        jQuery('#extraPagetitle-edit').rvsDialog('close');
    }
}
        </div>

<form method="post" name="form1" id="form1" action="">

    <?php echo $this->elements['rvsMgr']->toHtml();?> 
    <?php echo $this->elements['rvsAct']->toHtml();?>
    <div align="center"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'msgGet'))) if ($t->msgGet()) { ?><span><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'msgGet'))) echo $t->msgGet();?></span><?php }?></div>
    
    <table border="0" cellspacing="0" cellpadding="3" align="center" style="margin:20px 10px 0 10px;">
		<tr>
			<td width="35%" align="right" nowrap="nowrap"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Current Page Title");?> :</b></td>
			<td align="left"><font color="#646464"><span id="page_title"><?php echo $t->page_title;?></div></font></td>
		</tr>
		<tr>
			<td align="right" valign="top"><label for="new_page_title"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("New Page Title");?> :</b></label></td>
			<td align="left" valign="top">
				<?php if ($t->error['new_page_title'])  {?><div class="error"><?php echo $t->error['new_page_title'];?></div><?php }?>
				<?php echo $this->elements['new_page_title']->toHtml();?>
				<div class="error"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Max 255");?></div> 
				<?php 
if (!isset($this->elements['project_page_id']->attributes['value'])) {
    $this->elements['project_page_id']->attributes['value'] = '';
    $this->elements['project_page_id']->attributes['value'] .=  htmlspecialchars($t->project_page_id);
}
$_attributes_used = array('value');
echo $this->elements['project_page_id']->toHtml();
if (isset($_attributes_used)) {  foreach($_attributes_used as $_a) {
    unset($this->elements['project_page_id']->attributes[$_a]);
}}
?>
		</tr>
	</table>

</form>

</div>

 <div id="Extras_Pagetitle-success" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Change Page Title Name");?>">
        <div align="center" style="padding-top:20px;">  
        <span id="Extras_Pagetitle-message"></span>
        </div>
    </div>

</div>

