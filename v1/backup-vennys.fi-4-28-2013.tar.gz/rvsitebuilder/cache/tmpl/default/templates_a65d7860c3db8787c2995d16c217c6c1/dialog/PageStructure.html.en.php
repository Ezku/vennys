 
<!--Start Dialog Alert Msg -->
<div id="btnMoveUp" style="display:none">
<div id="alertMoveUp" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page up");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertMoveUp').rvsDialog('close');
    	}
	}
    </div>
   	<div class="txtpaddingtop"> <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page up");?>&nbsp;.</div>
</div>
</div>

<div id="btnMoveDown" style="display:none">
<div id="alertMoveDown" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page down");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertMoveDown').rvsDialog('close');
    	}
	}
    </div>
     <div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page down");?>&nbsp;.</div>
</div>
</div>

<div id="BtnMoveToSub" style="display:none">
<div id="alertMoveToSub" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("change to sub menu");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertMoveToSub').rvsDialog('close');
    	}
	}
    </div>
    <div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("change to sub menu");?>&nbsp; </div>
</div>
</div>

<div id="BtnMoveToTop" style="display:none">
<div id="alertMoveToTop" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("change to top menu");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertMoveToTop').rvsDialog('close');
    	}
	}
    </div>
    <div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("change to top menu");?>&nbsp; </div>
</div>
</div>

<div id="BtnUpIsHome" style="display:none">
<div id="alertUpIsHome" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page up");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertUpIsHome').rvsDialog('close');
    	}
	}
    </div>
	<div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?><br>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Sorry, can not move up. The upper page is Home Page.");?>&nbsp;</div>
</div>
</div>

<div id="MsgRenameEmpty" style="display:none">
<div id="alertRenameEmpty" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertRenameEmpty').rvsDialog('close');
    	}
	}
    </div>
	<div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Empty page name is prohibited. Please rename again.");?></div>
</div>
</div>

<div id="MsgRenamePageExist" style="display:none">
<div id="alertRenamePageExist" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename Page Exist");?>" style="display:none">
    <div class="dialog-option">
    closeOnEscape :true,
    width : "400px",
    buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
            jQuery('#alertRenamePageExist').rvsDialog('close');
        }
    }
    </div>
    <div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename Page Exist. Please rename again.");?></div>
</div>
</div>

<div id="MsgPageContentTagHtml" style="display:none">
	<div id="alertPageContentTagHtml" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Content Tag Html");?>" style="display:none">
	    <div class="dialog-option">
	    closeOnEscape :true,
	    width : "400px",
	    buttons:{
	        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
	            jQuery('#alertPageContentTagHtml').rvsDialog('close');
	        }
	    }
	    </div>
	    <div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Using html tag is forbidden");?>.</div>
	</div>
</div>

<div id="MsgRenameErr" style="display:none">
<div id="alertRenameErr" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertRenameErr').rvsDialog('close');
    	}
	}
    </div>
	<div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Empty page and page contain @ , ^ , and > is prohibited. Please ");?><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename page");?><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("again");?></div>
</div>
</div>

<div id="MsgAddPageEmpty" style="display:none">
<div id="alertAddPageEmpty" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertAddPageEmpty').rvsDialog('close');
    	}
	}
    </div>
	<div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Empty page name is prohibited. Please add new page again.");?></div>
</div>
</div>

<div id="MsgAddPageErr" style="display:none">
<div id="alertAddPageErr" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertAddPageErr').rvsDialog('close');
    	}
	}
    </div>
	<div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Empty page and page contain @ , ^ , and > is prohibited. Please ");?><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Add new page");?><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("again");?></div>
</div>
</div>

<div id="MsgDelHome" style="display:none">
<div id="alertDelHome" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("delete");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertDelHome').rvsDialog('close');
    	}
	}
    </div>
    <div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("delete");?>&nbsp;.</div>
</div>
</div>

<div id="MsglowerPage" style="display:none">
<div id="alertlowerPage" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page up");?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertlowerPage').rvsDialog('close');
    	}
	}
    </div>
    <div class="txtpaddingtop"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Sorry, there is a sub menu. Please delete the sub menu first.");?></div>
</div>
</div>

<div id="MsgConfigDB" style="display:none">
<div id="alertMsgConfigDB" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Add Extra Component"));?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertMsgConfigDB').rvsDialog('close');
    	}
	}
    </div>
    <div class="dialogPadding"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please, set database config");?></div>
</div>
</div>

<div id="MsgConfigDBOpt" style="display:none">
<div id="alertMsgConfigDBOpt" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Add Extra Component"));?>" style="display:none">
	<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        	jQuery('#alertMsgConfigDBOpt').rvsDialog('close');
    	}
	}
    </div>
    <div id ="msgErrConfigDB"></div>
</div>
</div>
<!--End Dialog Alert Msg -->

<!-- tryout page exist -->
<div id="MsgConfigPage" style="display:none">
<div id="alertMsgpageExist" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Add Extra Component"));?>" style="display:none">
    <div class="dialog-option">
    closeOnEscape :true,
    width : "400px",
    buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
            jQuery('#alertMsgpageExist').rvsDialog('close');
        }
    }
    </div>
    <div id ="msgpageExist"></div>
</div>
</div>

<!-- Start Rename Page New -->
<div id='ShowDialogPageEnter' style="display: none;">
	<div id ="DialogPageEnter" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename");?>" style="display: none;">	
		<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Save"));?>": function() {
    		jQuery.sitebuilder.PageStructure.cmdOk("#DialogPageEnter"); 
		},
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Cancel"));?>": function() {
         	jQuery("#DialogPageEnter").rvsDialog('close');
    	}
	}
   </div>
	<form name="frmPageEnter" method="post" id="frmPageEnter" action="<?php echo htmlspecialchars($t->frmAction);?>">
<table cellpadding="0" cellspacing="0" width="98%">
	<tr>
		<td>
			<div id="setTarget">
								<div class="ui-widget txtpaddingtop">
                                <div class="ui-state-highlight ui-corner-all">
                                     <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
                                     <div> <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Input change your page name");?></div>
                                     <div class="clearit"></div>                                                           
                                    <span class="ui-icon ui-icon-alert" style="float: left; margin-right: 0.3em;"></span>
                                     <div class="txtQuestionRename"> Not Support HTML tag.</div>
                </div>
                </div>
                <br>
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td class="bold" align="center"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Name");?> : <input type="text" name="pageEnter" id="pageEnter"></td>
					</tr>
				</table>
			</div>				
		</td>
	</tr>
</table>

</form>
	</div>
</div>
<!-- End Rename Page New -->

<!-- Start Add Page New -->
<div id='ShowDialogAddPageEnter' style="display: none;">
	<div id ="DialogAddPageEnter" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Add new page");?>" style="display: none;">	
		<div class="dialog-option">
	closeOnEscape :true,
	width : "400px",
	buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Save"));?>": function() {
    		jQuery.sitebuilder.PageStructure.addNewPage("#DialogAddPageEnter"); 
		},
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Cancel"));?>": function() {
         	jQuery("#DialogAddPageEnter").rvsDialog('close');
    	}
	}
   </div>
   
	<form name="frmAddPageEnter" method="post" id="frmAddPageEnter" action="<?php echo htmlspecialchars($t->frmAction);?>">
		<table cellpadding="0" cellspacing="0" width="98%">
	   <div class="ui-widget txtpaddingtop">
                <div class="ui-state-highlight ui-corner-all">
                <span class="ui-icon ui-icon-alert" style="float: left; margin-right: 0.3em;"></span>
                  <div class="txtQuestionRename"> Not Support HTML tag.</div>
	<tr>
		<td class="dialogPadding">
			<div id="setTarget">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td class="bold" align="center"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Name");?> : <input type="text" name="AddpageEnter" id="AddpageEnter"></td>
					</tr>
				</table>
			</div>				
		</td>
	</tr>
</table>

</form>
	</div>
</div>

<div id='pleasewaitcreatedb' style="display: none;">
	<div id ="pleasewaitcreatedb-step4" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please wait");?>" style="display: none;">	
		<div class="dialog-option">
	closeOnEscape :false,	
	width : "300px"
   </div>
   <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please wait");?> 
</div>
</div>
<div id ="DialogOpenDB" style="display:none"></div>
<!-- End Add Page New -->

<div id='ShowDialogPageDelete' style="display: none;">
    <div id ="DialogPageDelete" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Delete page");?>" style="display: none;"> 
        <div class="dialog-option">
    closeOnEscape :true,
    width : "400px",
    buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Ok"));?>": function() {
            jQuery.sitebuilder.PageStructure.deletePage("#DialogPageDelete"); 
        },
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Cancel"));?>": function() {
            jQuery("#DialogPageDelete").rvsDialog('close');
        }
    }
   </div>
   <div><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Are you sure want to delete page");?></div>  
    <div><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("If you deleted data in the entire page will be lost");?></div>    
    </div>
</div>
