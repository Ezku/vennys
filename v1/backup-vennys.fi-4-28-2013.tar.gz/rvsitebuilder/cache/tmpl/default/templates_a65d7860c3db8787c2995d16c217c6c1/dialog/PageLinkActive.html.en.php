<div id ="PageNavigator" style ="display: none;">
    <div id ="PageNavigator_mainPage" title ="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page link active");?>">
        <div class ="dialog-option">
        modal: true,
        closeOnEscape :true,
        width: 400,
        high: 200,
        buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
             jQuery(this).rvsDialog('close');
        },
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Ok");?>": function() {
            jQuery.sitebuilder.listPageStructure.mainPageStructureSave(jQuery(this));
        }
   },
   close : function() {
    jQuery('#pagelinkactive-msg').html('');
    jQuery('#showMsg').html('');
    
}

        </div>     
  <div id ="MainPageStructureShow-hide">
  	<div class="ui-widget dialogPadding"> 
		<div class="ui-state-highlight ui-corner-all" style ="diaplay:none"> 
			<span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
			  <div id ="showMsg"></div>
			  <div id="success" style ="display: none;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Update page link active successfully");?></div>
			  <div id="error" style ="display: none;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cannot update page link active");?></div>
			  <div id="ask" style ="display: none;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Do you want to disable page link ?");?></div>
			  <div id="pagelinkactive-msg"></div> 
		 </div>
	
		 <form method="post" name ="frmMainPageStructure" id ="frmMainPageStructure" action="">
			<input name ="rvsMgr" type ="hidden" value ="ListPageStructure" />
			<input name ="rvsAct" id ="rvsAct" type ="hidden" value ="updatePageLinkActive" /> 
			<input name ="project_page_id" id ="project_page_id" type ="hidden" value="">
			<input name ="subAct" id ="subAct" type ="hidden" value="">
			<input name ="rvs_link_id" id ="rvs_link_id" type ="hidden" value="">
			 
			   <div id ="radioPageLink" align="center">
					<input name="FrmOption[rvs_link_enable]" type="radio" id="radioPageLink_0" value="0" />
				   <label for="radioPageLink_0"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Yes");?></label>
				   <input name="FrmOption[rvs_link_enable]" type="radio" id="radioPageLink_1" value="1" checked />
					<label for="radioPageLink_1"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("No");?></label>
		
				</div>
			  
		</form>
	</div>   
 <div></div>
</div>