<style type="text/css">
body {  
    font-family: Verdana, Arial, Helvetica, sans-serif ;
    font-size:11px;
    margin: 0px 0px 0px 0px;
    padding: 0px 0px 0px 0px;
    background:#848484;
}
table {
    font-family: Verdana, Arial, Helvetica, sans-serif ;
    font-size:11px; 
}
/*************************************/
    
#popTuto {
    width:99%;
    height:248px;
    border:#000000 1px solid;
    background:#848484;
    padding:1px;
}
#popTuto .boder {
    border:#000000 1px solid;
    padding:0 0 0 0;
}
#popTuto .boder .top {
    background-image:url(<?php echo htmlspecialchars($t->helpPath);?>/images/bgTop.gif);
    background-repeat:repeat-x;
    background-position:top;
    background-color:#000000;
    color:#FFFFFF;
    font-weight:bold;
    padding:15px 0 10px 10px;
    border-bottom: #333333 solid 2px;
}
#popTuto .boder .bottom {
    background-image:url(<?php echo htmlspecialchars($t->helpPath);?>/images/bgBot.gif);
    background-repeat:repeat-x;
    background-color:#000000;
}
#popTuto .boder .body{
    color:#FFFFFF;
    text-decoration:none;
    background-image:url(<?php echo htmlspecialchars($t->helpPath);?>/images/bgtutorial.jpg);
    background-repeat:repeat-y;
    background-color:#686868;
    padding:0 0 20px 0;
}
#popTuto .boder .body a {
    color:#FFFFFF;
    text-decoration:none;
}
#popTuto .boder .body a:hover {
    color:#FBBF08;
}
</style>
<script>
function thisOpenPOP(url) {
var setTop = (screen.height - 600) / 2;
var setLeft = (screen.width - 800) / 2;
try{
 wysiwygHelpPOP = window.open(url,'wysiwygHelpPOP','width=800,height=600,left='+setLeft+',top='+setTop+',toolbar=0,resizable=0,scrollbars=0,status=0,menubar=0')
wysiwygHelpPOP.focus()
}catch(e){}
}
function closePOP() {
try{
wysiwygHelpPOP.close()
}catch(e){}
this.close()
}
function closeParentPOP(){
//alert.window.parent.name)
}



</script>
<div id="popTuto" valign="top">
    <div class="boder">
        <div class="top"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Wysiwyg VDO Tutorials");?> </div>
        <div class="body">
            <table border="0" height="90" cellspacing="0" cellpadding="0">
                <tr>
                    <td align="left" valign="top">
                        <div align="left" style="">
                            <span><a href="#" OnClick="thisOpenPOP('<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/index');parent.lightboxDeactivate()"><img src="<?php echo htmlspecialchars($t->helpPath);?>/images/tutorial01.jpg" alt="" width="211" height="124" border="0" /></a></span> 
                        </div>
                            <span style="padding-left:35px;"><a href="#" OnClick="thisOpenPOP('<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("view","help","sitebuilder"));?>category/wysiwyghelp/page/index');parent.lightboxDeactivate()"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("See Tutorials");?></a></span>                     
                    </td>
                    <td align="left" valign="top">
                        <div align="left" style="">
                            <span><a href="#" OnClick="parent.jQuery('#PageHelpWysiwyg').rvsDialog('close');"><img src="<?php echo htmlspecialchars($t->helpPath);?>/images/tutorial02.jpg" alt="" width="199" height="124" border="0" /></a></span> 
                        </div>
                            <span style="padding-left:50px;"><a href="#" OnClick="parent.jQuery('#PageHelpWysiwyg').rvsDialog('close');"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Build your web");?></a></span>                     
                    </td>
                </tr>
            </table>
        </div>
        <div class="bottom"></div>
    </div>
</div>