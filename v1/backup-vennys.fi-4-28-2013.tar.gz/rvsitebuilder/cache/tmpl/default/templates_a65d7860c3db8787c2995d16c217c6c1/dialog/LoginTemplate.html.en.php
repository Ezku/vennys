<div id="dialog-login-template-hidden" style="display: none;">

	<div id="dialog-login-template-set" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit Config Login Template");?>">
       <div class="dialog-option">
       		closeOnEscape :true,
			width:810,
			height:780,
			beforeclose2:function() {
				jQuery(this).find("#frameLoginTemplate").remove();
			} 
  	   </div> 
      
      <!-- set iframeLoginTemplate -->
      <div id="iframeLoginTemplate" style="width:100%"></div>
	</div>
	
	<!-- reset to default -->
	<div id="dialog-login-template-resettodefault" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("reset to default");?> : ">
		<div class="dialog-option">
 			modal: true,
			closeOnEscape :false,
			width: 600,
			buttons:{}
		</div>
		
		<form name="frmLoginTemplateResetTodefault" id="frmLoginTemplateResetTodefault" method="post">
	    	<input name="rvsMgr" type="hidden" value="clogintemplate" /> 
	    	<input name="rvsAct" type="hidden" value="reset_to_default" />
	        <input id="templateName" name="templateName" type="hidden" value="" />
	  	</form>

	</div>
	
	<!-- show message reset to default-->
	<div id="dialog-login-template-resettodefault-status" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Reset to default");?>">
        <div align="center" style="padding-top:20px;">  
        	<span id="login-template-resettodefault-status-message"></span>
        </div>
    </div>
    
</div>