 <div id="colorpicker" style="display:none;">  
    <div id="colorpicker-select" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Title Please Select ColorPicker");?>">
        
        <div id="btnDialogStd" style="display:none">  
            "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
                jQuery.sitebuilder.colorpicker.closeSelectColor(jQuery(this));
            },
            "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>": function() {
                jQuery.sitebuilder.colorpicker.saveColor(targetID,prefixPicker);
                jQuery.sitebuilder.colorpicker.closeSelectColor(jQuery(this));                                       
            }                                   
        </div>
        
        <div class="ui-widget dialogPadding">
            <?php echo $this->elements['colorPicker']->toHtmlnoClose();?>
                <table cellpadding="0" cellspacing="8" width="440" class="colorPicker">
                    <tr>
                        <td align="left" valign="bottom" width="99%">
                            
                            <fieldset class="bdrOuttable">
                            <legend><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Color Palette");?>: </b></legend> 
                    
                            <table cellspacing="0" cellpadding="0" align="center" width="100%">
                                <tr>
                                     <td align="center" valign="middle" class="border"> 
                                                                            
                                      <div id="displayThumbBorderColor" class="cpicker" target="thumbBorderColor" style="display:none;">
                                          <div id="displayThumbBorderColor_btnDialog" style="display:none">
                                              "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>": function() {
                                                    jQuery.sitebuilder.colorpicker.saveColor(targetID,prefixPicker);
                                                    jQuery.sitebuilder.colorpicker.closeSelectColor(jQuery(this));
                                                    
                                                    getThumbBorderColor = jQuery('#thumbBorderColor').val();
                                                },
											  "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
                                                    jQuery.sitebuilder.colorpicker.closeSelectColor(jQuery(this));
                                                }
                                          </div>
                                      </div>
									  
									  <div id="displayWaterMarkTextColor" class="cpicker" target="waterMarkTextColor" style="display:none;">
                                           <div id="displayWaterMarkTextColor_btnDialog" style="display:none">
                                           	   "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>": function() {
                                                    jQuery.sitebuilder.colorpicker.saveColor(targetID,prefixPicker);
                                                    jQuery.sitebuilder.colorpicker.closeSelectColor(jQuery(this));
                                                    
                                                    waterMarkTextColor = jQuery('#waterMarkTextColor').val();
                                                },
                                               "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
                                                    jQuery.sitebuilder.colorpicker.closeSelectColor(jQuery(this));
                                                }
                                                
                                           </div>
                                      </div>
									  
									  <div id="displayBackgroundThumbnailView" class="cpicker" target="backgroundThumbnailView" style="display:none;">
                                           <div id="displayBackgroundThumbnailView_btnDialog" style="display:none">
                                               "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>": function() {
                                                    jQuery.sitebuilder.colorpicker.saveColor(targetID,prefixPicker);
                                                    jQuery.sitebuilder.colorpicker.closeSelectColor(jQuery(this));
                                                    
                                                    waterMarkTextColor = jQuery('#backgroundThumbnailView').val();
                                                },
                                               "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
                                                    jQuery.sitebuilder.colorpicker.closeSelectColor(jQuery(this));
                                                }
                                                
                                           </div>
                                      </div>
                                      
                                        
                                   </td>
                              </tr>
                        </table>
                        </fieldset>
                        
                    </td>

                    <td align="left" valign="bottom" width="125">
                        <div class="borderRecent">
                            <div class="titleRecent"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Recentry used");?></div>
                            <div class="ColorRecent">
                                <div class="recentlyUseddd" id ="recentlyUseddd"></div>
                            </div>
                        </div>
                    </td>

                </tr>
                
                <tr>
                    <td colspan="3">
                        <div id="displayThumbBorderColor_Btn" style="display:none"></div>
                        <div id="displayWaterMarkTextColor_Btn" style="display:none"></div>
						<div id="displayBackgroundThumbnailView_Btn" style="display:none"></div>
                    </td>
                </tr>

            </table>
         </form>
      </div>
      
            
   </div>
</div>


     
<style type="text/css">
.b1 {
    height: 22px;
    width: 78px;
}
.b2 {
    height: 20px;
    width: 160px;
}
.t1 {
    height: 20px;
    width: 160px;
    text-align: center;
}
<!--

#tab_table {
    width: 286px;
    margin-top: 3px;
}
#tab_container {
    padding-top: 10px;
    border-left: 2px solid threedhighlight;
    border-right: 2px solid threeddarkshadow;
    border-bottom: 2px solid threeddarkshadow;
    height: 218px;
    width: 286px
}
-->
</style>

<style type="text/css">
.colorcell{
        height: 14px;
        width: 14px;
        border: 1px solid #FFFFFF; 
}
.colorcellselected{
        height: 12px;
        width: 12px;
        border: 1px solid #000000; 
}
.colorTable {
    width: 125px;
}
.colorTable a {
    background-color: transparent;
    border: 1px solid #000000;
    width: 13px;
    height: 13px;
    display: block;
    overflow:hidden;
    float: left;
    color: #000000;
    text-decoration:none;
    padding: 0px;
    font-size: 6px;
}


.colorPicker {
color:#000000;
font-size:12px;
margin:0;
padding:0;
}
.colorPicker .bdrOuttable {
border:1px solid #B0B0B0;
padding:5px;
}
.colorPicker .bdrOuttable legend {
color:#000000;
}
.colorPicker .border {
border:1px solid #B0B0B0;
margin:0;
padding:0;
}
.colorPicker input.btnDefault {
background-color:#F1F1F1;
border:1px solid #BEBEBE;
color:#040001;
font-weight:bold;
text-align:center;
width:100%;
}
.colorPicker .showColor {
border:1px solid #898788;
}
.colorPicker .borderRecent {
border:1px solid #B0B0B0;
height:170px;
padding:3px;
}
.colorPicker .titleRecent {
background-color:#F1F1F1;
border:1px solid #BEBEBE;
color:#040001;
font-weight:bold;
margin-bottom:3px;
padding:3px 5px;
text-align:center;
white-space:nowrap;
width:auto;
}
.colorPicker .ColorRecent {
border:1px solid #939393;
color:#040001;
height:135px;
padding:3px;
margin-bottom:3px;
width:auto;
}
</style>


 
 
 
 
 <!-- start rename album gallery -->
 <?php echo $t->scriptOpen;?>
 var addFrmPhoto=0;
 <?php echo $t->scriptClose;?>
 <div id="mgrranameAlbum" style="display:none">
  <div id="dialog-gallery-rename" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Title Please confirm");?>">
        <div class="dialog-option">
			modal: true,
			closeOnEscape :true,
			doBeforeclose2:function(){
					jQuery("#showMsgGalleryRename").html("");
			},
			width: 400,
			buttons:{
			    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename");?>": function() {
				    if(jQuery("#renameAlbum").val() == ""){
						jQuery("#showMsgGalleryRename").html("<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Album name not null");?>");
					} else {
			       		jQuery.sitebuilder.rvsPhotoGallery.editviewalbumname(jQuery(this));
					}
			    },
				 "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
			        jQuery(this).rvsDialog("close");
			    }
			}
		 </div> 
		<div class="dialogPadding">	 
		    <div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
				<span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please Enter the album name to format");?>
			    <div id="showMsgGalleryRename"></div>
		   </div> 
			<form name="dialog-gallery-rename-form" id="dialog-gallery-rename-form" action="">
				<input name="rvsMgr" type="hidden" value="rvsPhotoGallery" /> 
		    	<input name="rvsAct" type="hidden" value="editAlbumName" />
				<input name="galleryId" type="hidden" value="<?php echo htmlspecialchars($t->galleryId);?>" />
		    	<input name="albumId" id="albumIdForRename" type="hidden" value="" />
				<table cellspacing="5" cellpadding="0" align="center">
					<tr><td align="left" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Rename album");?></b></td></tr>
					<tr><td align="left" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Album Name");?>: </b><input type="text" name="albumName" id="renameAlbum" value="" /></td></tr>
				</table>	
			</form>
		</div>
	</div>
</div>
 <!-- end  rename album gallery -->
 
  <!-- start edit description  album gallery -->
 <div id="mgrDescAlbum" style="display:none">
  <div id="dialog-gallery-desc" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit album description");?>">
        <div class="dialog-option">
			modal: true,
			closeOnEscape :true,
			doBeforeclose2:function(){
					jQuery("#showMsgGalleryDesc").html("");
			},
			width: 500,
			buttons:{
			    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Update");?>": function() {
			        jQuery.sitebuilder.rvsPhotoGallery.editAlbumDesc(jQuery(this));
			    },
				 "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
			        jQuery(this).rvsDialog("close");
			    }
			}
		 </div>  
		 
    
    	<div class="dialogPadding">	
		    <div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
			<span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
			<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please enter description");?>	
		    <div id="showMsgGalleryDesc"></div>
		   </div> 
			<form name="dialog-gallery-desc-form" id="dialog-gallery-desc-form" action="">
				<input name="rvsMgr" type="hidden" value="rvsPhotoGallery" /> 
		    	<input name="rvsAct" type="hidden" value="editAlbumDesc" />
				<input name="galleryId" type="hidden" value="<?php echo htmlspecialchars($t->galleryId);?>" />
		    	<input name="albumId" id="albumIdDesc" type="hidden" value="" />
				<table cellspacing="5" cellpadding="0" align="center" width="100%">
					<tr><td valign="top" align="right"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Album");?>: </b></td><td valign="top" align="left"><span id="showtxtAlbumName"></span></td></tr>
					<tr><td valign="top" align="right"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Description");?>: </b></td><td valign="top" align="left"><textarea cols="30" rows="6" name="albumDesc" id="descAlbum"></textarea></td></tr>
				</table>	
			</form>
		</div>
	</div>	
</div>
  <!-- end edit description  album gallery -->
  
  <!-- start delete  album gallery -->
 <div id="mgrDeleteAlbum" style="display:none">
  <div id="dialog-gallery-delete" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Title Please confirm");?>">
        <div class="dialog-option">
			modal: true,
			closeOnEscape :true,
			doBeforeclose2:function(){
					jQuery("#showMsgGalleryDelete").html("");
			},
			width: 400,
			buttons:{
			    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Delete");?>": function() {
			        jQuery.sitebuilder.rvsPhotoGallery.deleteAlbum(jQuery(this));
			    },
				"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
			        jQuery(this).rvsDialog("close");
			    }
			}
		 </div> 
		 
		 <div class="dialogPadding">	
		    <div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
				<span class="ui-icon ui-icon-notice" style="float: left; margin-right: 0.3em;"></span>
				<div class="txtTitle"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Are you sure to delete?");?></div>
			    <div id="showMsgGalleryDelete"></div>
		   	</div> 	 
			<form name="dialog-gallery-delete-form" id="dialog-gallery-delete-form" action="">
				<input name="rvsMgr" type="hidden" value="rvsPhotoGallery" /> 
		    	<input name="rvsAct" type="hidden" value="deleteAlbum" />
				<input name="galleryId" type="hidden" value="<?php echo htmlspecialchars($t->galleryId);?>" />
		    	<input name="albumId" id="albumIdDelete" type="hidden" value="" />
				<table cellspacing="5" cellpadding="0" align="center">
					<tr><td align="center" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Album");?>: </b><span id="showtxtDelAlbumName"></span></td></tr>
				</table>	
			</form>
		</div>
	</div>
</div>
  <!-- end delete description  album gallery -->
<!-- start edit cover  album gallery -->
  <div id="dialog-rvsphotogallery-dialogcover" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Edit Cover"));?>">
             <div class="dialog-option">
           modal:true,
           closeOnEscape:true,
           width:600,
           buttons:{
               "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upload");?>": function() {
                   jQuery.sitebuilder.rvsPhotoGallery.editCover();
               },
               "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
                   jQuery('#dialog-rvsphotogallery-dialogcover').rvsDialog('close');
               }
           }
       </div>
             <form name="frm-dialog-cover" id="frm-dialog-cover" method="post" enctype="multipart/form-data">
                    <input id="rvsMgr" name="rvsMgr" type="hidden" value="rvsPhotoGallery" />           
		            <input id="rvsAct" name="rvsAct" type="hidden" value="editCover" />
			        <input name="moduleName" type="hidden" value="sitebuilderpro" />
			        <input name="galleryId" type="hidden" value="<?php echo htmlspecialchars($t->galleryId);?>" />
			        <input name="albumId" type="hidden" id="albumIdCover" value="" />
					<input name="project_page_id" type="hidden" id="project_page_id" value="" />

             <div class="ui-widget dialogPadding">
                             <div class="ui-state-highlight ui-corner-all">
                   <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
                   <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Supporting file extension .gif .jpg .jpeg and .png");?><br />
               </div>
			   <table width="100%" cellpadding="0" cellspacing="5">
			   	<tr><td height="10"></td><td></td></tr>
			   	<tr>
			   	<td align="left" valign="top">
			   		<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/space.gif" id="showImgCover" />
			   	</td>
				<td align="left" valign="top" width="99%"> 
				<div>
				<br />
				<b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Select file");?>: </b>
                   <!-- <input id="upload-header-background-file" name="upload-header-background-file" type="file" /> -->
                   <input id="upload-cover-file" name="upload-cover-file" type="file" />
                  </div>
				  </td>
				  </tr>
                  
				</table>
                     </div>
             </form>
             </div> 
  <!-- end edit cover  album gallery -->
  
   
  <!-- start add folder  album gallery -->
 <div id="viewAddNewFolder" style="display:none">
  <div id="dialog-view-add-new-folder" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Create folder");?>">
  <div class="dialogPadding">	
 	 <div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
        <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
        <div id ="showMsgInfo"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please enter folder name to format");?></div>		
		<div id ="showMsgAddFolder"></div> 
     </div>
	 
     <div class="dialog-option">
            modal: true,
            closeOnEscape :true,
            width: 500,
            buttons:{
                "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Create");?>": function() {
                    jQuery.sitebuilder.rvsPhotoGallery.addNewFolder("#dialog-view-add-new-folder");
                },
				"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
                    jQuery("#dialog-view-add-new-folder").rvsDialog('close');
                }
            }

     </div>  
     <form name="dialog-view-add-new-folder-form" id="dialog-view-add-new-folder-form" action="">
        <input name="rvsMgr" type="hidden" value="rvsPhotoGallery" /> 
        <input name="rvsAct" type="hidden" value="addNewFolder" />
        <input name="galleryId" id="galleryId" type="hidden" value="" />
        <input name="albumId" id="albumId" type="hidden" value="" />
	   	<input name="folderPath" id="folderPath" type="hidden" value="" />
	   	<input name="folderId" id="folderId" type="hidden" value="" />
	   	<input name="parentId" id="parentId" type="hidden" value="" />
	   
        
        <table width="100%" cellpadding="0" cellspacing="5">
			<tr>
			   	<td align="right" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Folder name");?>: </b></td>
        		<td align="left" valign="top"><input type="text" name="folderName" id="folderName" value="" /></td>
        	</tr>
        	<tr>
			   	<td align="right" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Description");?>: </b></td>
        		<td align="left" valign="top"><textarea cols="30" rows="6" name="folderDesc" id="folderDesc"></textarea></td>
        	</tr>
        </table>         
    </form>
    </div>
</div>
</div>
  <!-- end add folder album gallery -->
  
    
 <!-- start edit folder  album gallery -->
 <div id="viewEditFolder" style="display:none">
  <div id="dialog-view-edit-folder" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit folder");?>">
  <div class="dialogPadding">
     <div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
        <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
        <div id ="showMsg"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please enter folder name to format");?></div>      
     </div>
     <div class="dialog-option">
            modal: true,
            closeOnEscape :true,
            width: 500,
            buttons:{
                "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>": function() {
                    jQuery.sitebuilder.rvsPhotoGallery.editFolder("#dialog-view-edit-folder");
                },
                "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
                    jQuery("#dialog-view-edit-folder").rvsDialog('close');
                }
            }

     </div>  
     <form name="dialog-view-edit-folder-form" id="dialog-view-edit-folder-form" action="">
        <input name="rvsMgr" type="hidden" value="rvsPhotoGallery" /> 
        <input name="rvsAct" type="hidden" value="editFolder" />
        <input name="galleryId" id="galleryId" type="hidden" value="" />
        <input name="albumId" id="albumId" type="hidden" value="" />
        <input name="parentPath" id="parentPath" type="hidden" value="" />
		<input name="oldFolderName" id="oldFolderName" type="hidden" value="" />
		<input name="oldFolderDesc" id="oldFolderDesc" type="hidden" value="" />
		<input name="folderId" id="folderId" type="hidden" value="" />

        <table width="100%" cellpadding="0" cellspacing="5">
			<tr>
			   	<td align="right" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Folder name");?>: </b></td>
        		<td align="left" valign="top"><input type="text" name="newFolderName" id="newFolderName" value="" /></td>
        	</tr>
        	<tr>
			   	<td align="right" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Description");?>: </b></td>
        		<td align="left" valign="top"><textarea cols="30" rows="6" name="newFolderDesc" id="newFolderDesc"></textarea></td>
        	</tr>
        </table>             
    </form>
    </div>
</div>
</div>
  <!-- end add folder album gallery -->
  
   <!-- start delete folder  album gallery -->
 <div id="viewDeleteFolder" style="display:none">
  <div id="dialog-view-delete-folder" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Delete folder");?>">
  <div class="dialogPadding">
     <div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
        <span class="ui-icon ui-icon-notice" style="float: left; margin-right: 0.3em;"></span>
        <div id ="showMsg" class="txtTitle"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Are you sure want to delete folder");?></div> 
     </div>
     <div class="dialog-option">
            modal: true,
            closeOnEscape :true,
            width: 400,
            buttons:{
                "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Ok");?>": function() {
                    jQuery.sitebuilder.rvsPhotoGallery.deleteFolder("#dialog-view-delete-folder");
                },
                "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
                    jQuery("#dialog-view-delete-folder").rvsDialog('close');
                }
            }

     </div>  
     <form name="dialog-view-delete-folder-form" id="dialog-view-delete-folder-form" action="">
        <input name="rvsMgr" type="hidden" value="rvsPhotoGallery" /> 
        <input name="rvsAct" type="hidden" value="deleteFolder" />
        <input name="galleryId" id="galleryId" type="hidden" value="" />
        <input name="parentPath" id="parentPath" type="hidden" value="" />
        <input name="folderId" id="folderId" type="hidden" value="" />
		<input name="folderName" id="folderName" type="hidden" value="" />
		<input name="parentId" id="parentId" type="hidden" value="" />
       <table cellspacing="5" cellpadding="0" align="center">
            <tr><td align="center" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Album");?>: </b><span id="showtxtDelFolderName"></span></td></tr>
        </table>
                  
    </form>
    </div>
</div>
</div>
  <!-- end delete folder album gallery -->
  
   <!-- start add new  album gallery -->
<div id="dialog-addNewAlbumListData" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Title Please confirm");?>">
<div class="dialog-option">
closeOnEscape :true,
doBeforeclose2:function(){
		jQuery("#showMsgCreateAlbum").html("");
		jQuery("input[name=albumName]").val("");
		jQuery("textarea[name=albumDesc]").val("");
},
buttons:{
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Save"));?>": function() {
		 		if(jQuery("#albumNameForAddAblum").val() == ""){
						jQuery("#showMsgCreateAlbum").html("<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Album name not null");?>");
				} else {
			       		jQuery.sitebuilder.rvsPhotoGallery.createNewAlbumDialog(jQuery(this));
				}
		},
    	"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Cancel"));?>": function() {
            jQuery(this).rvsDialog("close");
    	}
}
       </div>
     	<div class="dialogPadding">  
			<div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
				<span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
				<div id ="showMsgInfoAddAlbum"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please Enter the album name to format");?></div>		
				<div id ="showMsgCreateAlbum"></div> 
			</div>
			<div><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Album");?>: </b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Create Album");?></div>
			<?php echo $this->elements['frmcreateAlbum']->toHtmlnoClose();?>
				<?php echo $this->elements['rvsMgr']->toHtml();?> 
				<?php echo $this->elements['rvsAct']->toHtml();?> 
				<?php 
if (!isset($this->elements['galleryId']->attributes['value'])) {
    $this->elements['galleryId']->attributes['value'] = '';
    $this->elements['galleryId']->attributes['value'] .=  htmlspecialchars($t->galleryId);
}
$_attributes_used = array('value');
echo $this->elements['galleryId']->toHtml();
if (isset($_attributes_used)) {  foreach($_attributes_used as $_a) {
    unset($this->elements['galleryId']->attributes[$_a]);
}}
?> 
				<?php 
if (!isset($this->elements['project_page_id']->attributes['value'])) {
    $this->elements['project_page_id']->attributes['value'] = '';
    $this->elements['project_page_id']->attributes['value'] .=  htmlspecialchars($t->project_page_id);
}
$_attributes_used = array('value');
echo $this->elements['project_page_id']->toHtml();
if (isset($_attributes_used)) {  foreach($_attributes_used as $_a) {
    unset($this->elements['project_page_id']->attributes[$_a]);
}}
?> 
			<table cellpadding="0" cellspacing="5">
				<tr>
					<td align="right" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Album Name");?>: </b></td>
					<td align="left" valign="top"><?php echo $this->elements['albumName']->toHtml();?></td>
				</tr>
				<tr>
					<td align="right" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Description");?>: </b></td>
					<td align="left" valign="top"><?php echo $this->elements['albumDesc']->toHtml();?></td>
				</tr>
			</table>
			
			</form>
		</div>
	</div> 
  <!-- end add new  album gallery -->
  
      <div id="rvsGallery-waitting" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please wait");?>">
        <div class="dialog-option">
closeOnEscape :false
        </div>
        <div class="ui-progressbar-indicator">  
        <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please wait");?>...
        </div>
    </div>  jQuery('#gallery-msg-success').html(data.msg);

<!-- Open Msg for Gallery -->
<div id="showResultMsg">
<div class="ui-widget">
	<div class="ui-state-highlight ui-corner-all"> 
    <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
                  <div id="gallery-msg-success"> </div>
                  <div id="gallery-msg-error"> </div>
	</div>
</div>
</div>
<!-- Close Msg for Gallery -->

 <!-- start delete  photo gallery -->
 <div id="mgrDeletePhoto" style="display:none">
  <div id="dialog-photo-delete" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Title Please confirm");?>">
  	<div class="dialogPadding">  
  		<div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
        	<span class="ui-icon ui-icon-notice" style="float: left; margin-right: 0.3em;"></span>
	        <div id ="showMsginfo" class="txtTitle"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Are you sure want to delete photo");?></div>
			<div id ="showMsgsuccess"></div>       
     	</div>
        <div class="dialog-option">
			modal: true,
			closeOnEscape :true,
			width: 400,
			buttons:{
				 "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Delete");?>": function() {
			        jQuery.sitebuilder.rvsPhotoGallery.deletePhoto(jQuery("#dialog-photo-delete"));
			    },
				 "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
                    jQuery(this).rvsDialog("close");
                }
			}
		 </div>  
		<form name="dialog-photo-delete-form" id="dialog-photo-delete-form" action="">
			<input name="rvsMgr" type="hidden" value="rvsPhotoGallery" /> 
	    	<input name="rvsAct" type="hidden" value="deletePhoto" />
			<input name="galleryId" id="galleryId" type="hidden" value="" />
	    	<input name="albumId" id="albumId" type="hidden" value="" />
			<input name="folderPath" id="folderPath" type="hidden" value="" />
			<input name="imageName" id="imageName" type="hidden" value="" />
			<input name="imageId" id="imageId" type="hidden" value="" />
			<table cellspacing="5" cellpadding="0" align="center">
				<tr><td align="center" valign="top"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("photo");?>: </b> <span id="showtxtDelPhotoName"></span></td></tr>
			</table>
		</form>
	</div>
</div>
</div>
  <!-- end delete photo album gallery -->
 
  <!-- start save description  photo gallery -->
 <div id="savedescriptionPhoto" style="display:none">
  <div id="dialog-photo-saveDesc" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>">
  
  	<div class="ui-state-highlight ui-corner-all" style ="diaplay:none; margin:20px 20px 0px 20px;"> 
        <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
        <div id ="showMsg"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Success");?></div>      
     </div>
        <div class="dialog-option">
        	modal: true,
			closeOnEscape :true,
			width: 400
		 </div>  
</div>
</div>
  <!-- end save description photo album gallery -->
  
 <!-- start show  photo gallery -->
 <div id="uploadphoto" style="display:none">
    <div id="dialog-upload-photo" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upload photo");?>">
  	
        <div class="dialog-option">
        	modal: true,
			closeOnEscape :true,
			width: 900,
			height: 700,
			buttons:{
			    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
			        jQuery.sitebuilder.rvsPhotoGallery.closePhoto(jQuery("#dialog-upload-photo"));
			    }
			}
		 </div>  
		<!-- <flexy:include src="addViewPhoto.html" />-->
    <div id="body-dialog-upload-photo" attrAddmorePhoTo="0"></div>
    </div>
</div>
  <!-- end show photo album gallery -->
  
   <!-- start save description  image album gallery -->
 <div id="savedescriptionimage" style="display:none">
  <div id="dialog-image-saveDesc" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit photo Description");?>">
  	<div class="dialogPadding"> 
  	 	<div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
        	<span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>       
        	<div id ="showMsgSaveImg"></div> 
     	</div>
        <div class="dialog-option">
           modal: true,
            closeOnEscape :true,
            width: 500,
            buttons:{
                 "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Update");?>": function() {
                    jQuery.sitebuilder.rvsPhotoGallery.saveDescPhoto("#dialog-image-saveDesc");
                },
				"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
                    jQuery(this).rvsDialog("close");
                }
            }
        </div>  
	    <form name="dialog-image-desc-form" id="dialog-image-desc-form" action="">
	        <input name="rvsMgr" type="hidden" value="rvsPhotoGallery" /> 
	        <input name="rvsAct" type="hidden" value="saveDescPhoto" />
	        <input name="galleryId" id="galleryId" type="hidden" value="" />
	        <input name="albumId" id="albumId" type="hidden" value="" />
			<input name="folderPath" id="folderPath" type="hidden" value="" />
		    <input name="imageName" id="imageName" type="hidden" value="" />
			<input name="imageId" id="imageId" type="hidden" value="" />
	        <table cellspacing="5" cellpadding="0" align="center">
                    <tr><td valign="top" align="right"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("photo");?>: </b></td><td valign="top" align="left"><span id="showtxtimageDes"></span></td></tr>
                    <tr><td valign="top" align="right"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Description");?>: </b></td><td valign="top" align="left"><textarea cols="30" rows="6" name="imgDesc" id="imgDesc"></textarea></td></tr>
            </table>       
	    </form>
    </div>
</div>
</div>
  <!-- end save description  image album gallery -->
  
  <!-- start show image mouse over gallery -->
 <div id="showImageOver" style="display:none">
    <div id="dialog-show-image">
    
        <div class="dialog-option">
            modal: true,
            closeOnEscape :true,
            width: 600,
            height: 400
         </div>  
        <div>     
                <img id="ImageOverView" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/space.gif">
        </div>  
    </div>
</div>
  <!-- end  show image mouse over gallery -->
  
    <!-- start show image menu photo manengement gallery -->
 <div id="showImagePhotoManenge" style="display:none">
    <div id="dialog-show-image_photo_manenge">
    
        <div class="dialog-option">
            modal: true,
            closeOnEscape :true,
            width: 800,
            height: 600,
			 buttons:{
                "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("close");?>": function() {
                    jQuery(this).rvsDialog("close");
                    }
				}
         </div>   
                <img onclick="jQuery.sitebuilder.rvsPhotoGallery.openVewImageManenge(jQuery(this))" id="showImageManenge" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/space.gif" imageUrlOrg="" isImageOrg="" overView="1" width="500" height="200">
    </div>
</div>
  <!-- end  show image menu photo manengement  gallery -->
  
  <!-- start show  Dialog MultiSelectBox -->
 <div id="show-dialog-multi-selectbox" style="display:none">
    <div id="dialog-show-dialog-multi-selectbox" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Select MultiBox");?>">
        <div class="dialog-option">
        	modal: true,
			closeOnEscape :true,
			width: 535,
			height: 500,
			resizable:true,
			buttons:{
				 "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Go to upload");?>": function() {
			       	   jQuery.sitebuilder.rvsPhotoGallery.saveMultiSelectBox(jQuery(this));
			    },
				 "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
			        jQuery(this).rvsDialog("close");
			    }
			}
		 </div> 
	 
	<div class="ui-state-highlight ui-corner-all" style ="diaplay:none; margin:20px 20px 0px 20px;"> 
        <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>       
        <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please select the folder you want to upload photos");?>
     </div>
    <div id="selectMultiBox"></div>
    </div>
</div>
<!-- end show  Dialog MultiSelectBox -->

  <!-- start confirm move photo gallery -->
<div id="confirmMovePhoto" style="display:none">
  <div id="dialog-confirm-move-photo" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("confirm move photo");?>">
  	<div class="dialogPadding">
	    <div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
	        <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>       
	        <div id ="showMsgMoveImgInfo"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("confirm move photo");?></div> 
	        <div id ="showMsgMoveImg"></div> 
	     </div>
	        <div class="dialog-option">
	             modal: true,
	            closeOnEscape :true,
	            width: 400,
	            height: 200,
	            buttons:{
	                "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move");?>": function() {
	                    jQuery.sitebuilder.rvsPhotoGallery.movePhotoManenge('#dialog-confirm-move-photo');
	                },
	                 "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
	                    jQuery(this).rvsDialog("close");
	                }
	            }
	         </div>  
	
		      <form name="dialog-confirm-move-photo-form" id="dialog-confirm-move-photo-form" action="">
		        <input name="rvsMgr" id="rvsMgr" type="hidden" value="rvsPhotoGallery" /> 
		        <input name="rvsAct" id="rvsAct" type="hidden" value="movePhoto" />
		        <input name="galleryId" id="galleryId" type="hidden" value="" />
		        <input name="newImageId" id="newImageId" type="hidden" value="" />
		        <input name="newAlbumId" id="newAlbumId" type="hidden" value="" />
		        <input name="newFolderPath" id="newFolderPath" type="hidden" value="" />
		        <input name="folderPath" id="folderPath" type="hidden" value="" />
		        <input name="photoId" id="photoId" type="hidden" value="" />
		        
		    </form>
		</div>
    </div>
</div>
  <!-- end  confirm move photo gallery -->
  
   <!-- start show  photo mouse over album manegement -->
 <div id="showPhotoMouseOver" style="display:none">
    <div id="dialog-show-photo-mouse-over" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("show photo");?>">
    
        <div class="dialog-option">
            modal: true,
            closeOnEscape :true,
            width: 750,
            height: 550,
            buttons:{
                "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
                    jQuery(this).rvsDialog("close");
                }
            }
         </div>  
    <div id="show-photo-mouse-over-manegement"></div>
    </div>
	<!-- end  show  photo mouse over gallery album manegement-->
	
	<!-- Status Re-GeneralThumb -->
        <div id="dialog-regerate-thumb" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Status Re-Generate Thumbnail");?>">
		     
			 <div class="dialog-option">
		           modal: true,
		           closeOnEscape :true,
		           width: 320,
		           height: 60
		     </div>  
			 
			 <!-- #99e  style="height: 1em;-->
			 <div id="msg-status-regerate-thumb" style="height: 18px; width: 280px; border:1px solid #000;margin:15px;">
			     <div id='progress'><div id="pbar" style="background: #0FE30E; height: 15px; width:0%; float:left;"></div></div>
			     <div id="ppct" style="height: 15px; position: absolute; margin: 1 0 0 185;"></div>
			 </div>
			 <!-- <div id="ptxt" style="margin: 3 0 0 5">0 of 0 bytes</div> -->
			 
	   </div>
	<!-- End Status Re-GeneralThumb -->
	
	
	<!-- Dialog Confirm Re-GeneralThumb -->
        <div id="dialog-confirm-regerate-thumb" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Confirm Re-Generate Thumbnail");?>">
             
             <div class="dialog-option">
                    modal: true,
                    closeOnEscape :false,
                    width: 400,
                    height: 200,
                     buttons:{
		                "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Re-GenerateThumb");?>": function() {
						    
							project_page_id = jQuery('#dialog-confirm-regerate-thumb').find('#rethumb_project_page_id').val();
						    galleryId = 'gallery_' + project_page_id;
							
							jQuery('#dialog-confirm-regerate-thumb').rvsDialog('close');
							
                            jQuery.sitebuilder.rvsPhotoGallery.reGenerateThumb(galleryId, project_page_id, 'start', 1, 'noredirect');
		                },
		                 "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
		                    jQuery('#dialog-confirm-regerate-thumb').rvsDialog("close");
		                }
		           }
             </div>  
            
			<div class="ui-state-highlight ui-corner-all" style ="diaplay:none; margin:20px 20px 0px 20px;"> 
                <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
                <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Do you want to re-generate thumb now");?>
            </div> 
			<!-- get project_page_id -->
			<input type="hidden" id="rethumb_project_page_id" value="" /> 
             
       </div>
    <!-- End Dialog Confirm Re-GeneralThumb -->
	
	<!-- Dialog NOT FOUND FTP FILE -->
	<div id="dialog-notfound-ftp-file" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("File not found");?>">
             
             <div class="dialog-option">
                    modal: true,
                    closeOnEscape :false,
                    width: 400,
                    height: 200,
                     buttons:{
                         "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
                            jQuery('#dialog-notfound-ftp-file').rvsDialog("close");
                        }
                   }
             </div>  
            
            <div class="ui-state-highlight ui-corner-all" style ="diaplay:none; margin:20px 20px 0px 20px;"> 
                <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
                <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("File not found");?>
            </div> 
             
       </div>
	   <!-- END Dialog NOT FOUND FTP FILE -->
	   
	     <!-- start move photo gallery error -->
<div id="errorMovePhoto" style="display:none">
  <div id="dialog-error-move-photo" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Error move photo");?>">
    <div class="dialogPadding">
        <div class="ui-state-highlight ui-corner-all" style ="diaplay:none;"> 
            <span class="ui-icon ui-icon-alert" style="float: left; margin-right: 0.3em;"></span>       
            <div id ="showErrMsgMoveImg"></div> 
         </div>
            <div class="dialog-option">
                 modal: true,
                closeOnEscape :true,
                width: 400,
                height: 200,
                buttons:{
                     "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
                        jQuery(this).rvsDialog("close");
                    }
                }
             </div>  
        </div>
    </div>
</div>
  <!-- end  move photo gallery error -->
  
</div>
  
  

  