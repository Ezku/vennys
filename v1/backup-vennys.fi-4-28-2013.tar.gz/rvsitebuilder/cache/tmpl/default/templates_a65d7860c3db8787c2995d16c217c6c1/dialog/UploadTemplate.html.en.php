<!-- user-->
<div id="windowconfigviewlog" style="display: none;"> 
    <div id="uploadFormx" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upload Template");?>">
        <div class="dialog-option">
width:600,
modal: false,
closeOnEscape :true,
buttons:{

<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if ($t->isAdmin()) { ?>
"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Upload");?>": function() {
        jQuery.sitebuilder.uploadtemplateDA.doUploadTemplate('#frmUploadTemplate','submitUpload');
    },
<?php } else {?>
"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import and go to template catalogue");?>": function() {
        jQuery.sitebuilder.uploadtemplateDA.doUploadTemplate('#frmUploadTemplate','submitUpload');
    },
"<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import and go to step 3");?>": function() {
        jQuery.sitebuilder.uploadtemplateDA.doUploadTemplate('#frmUploadTemplate','submitUploadGoToStep3');
    },
<?php }?>
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        jQuery(this).rvsDialog('close');
    }
}

</div>
<div align="center" style="padding-top:20px;">   
<form action="<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("getHomeUrl"));?>/CMD_FILE_MANAGER" method="post" enctype="multipart/form-data" id="frmUploadTemplate" name="frmUploadTemplate">
<div align="center" class="dialogPadding"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Select file");?>&nbsp;
<input name="file1" id="file1" class="fileDirectAdmin" type="file" />
<input type="hidden" id="pathDA" name="path" value="/.rvsitebuilder/tmp">
<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo htmlspecialchars($t->uploadMaxFileSize);?>">
<input type="hidden" id="directAdminAction" name="action" value="upload">
</div>
</form>
</div>
</div>
</div>


<!-- 
<div id="windowconfigviewlog1" style="display: none;"> 
    <div id="uploadFormx" title="{translate(#Upload Logo#):h}">
        <div class="dialog-option">
        modal: false,
closeOnEscape :true,
buttons:{
"{translate(#Upload#):h}": function() {
        jQuery.sitebuilder.uploadtemplateDA.doUploadTemplate('#frmUploadTemplateUser');
    },
    "{translate(#Cancel#):h}": function() {
        jQuery(this).rvsDialog('close');
    }
}

</div>
<div align="center" style="padding-top:20px;">   
<table width="300" cellpadding="4" cellspacing="0" align="left">
<tr><td>
<form action="{this.plugin(#getHomeUrl#)}/CMD_FILE_MANAGER" method="post" enctype="multipart/form-data" id="frmUploadTemplateUser" name="frmUploadTemplateUser"  FLEXY:IGNORE="yes">
{translate(#File#):h}: 
<input name="file1" id="file1" class="fileDirectAdmin" type="file" />
<input type="hidden" id="pathDA" name="path" value="/.rvsitebuilder/tmp">
<input type="hidden"  name="MAX_FILE_SIZE" value="{uploadMaxFileSize}">
<input type="hidden" id="directAdminAction" name="action" value="upload">
</form>
</td>
</tr>
</table>
</div>
</div>
</div>
-->
