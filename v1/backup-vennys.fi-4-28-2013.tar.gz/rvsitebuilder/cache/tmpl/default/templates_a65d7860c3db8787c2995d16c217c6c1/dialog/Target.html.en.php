<div id="target" style="display: none;">  
  <div id="targetLink-set" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Set Target");?>">
       <div class="dialog-option">
        
closeOnEscape :true,
width :"500px",
buttons:{
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        jQuery(this).rvsDialog('close');
    },
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Ok");?>": function() {
   jQuery.sitebuilder.listPageStructure.targetLinkImage(jQuery(this));
    }
}
  </div> 
      
  <div id="targetLink-content" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Title Please confirm");?>">
           <div class="ui-widget dialogPadding">
                <div class="ui-state-highlight ui-corner-all">
				<span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
                    <div id="targetLink-content-page">
					<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please select link target.");?>
		            </div>
		            <div id="targetLink-content-msg"> 
		            <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Select link target is successfully.");?>
		            </div>
                </div>
            </div> 
</div>    
      
      
      
      
      
      
      
      
      
<!-- Target Ajax -->
<form name="FrmOption[]" id="frmTarget" action="">

<div style="position:;display:none;" id="targetLinkLoading">
<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/loading02.gif" alt="" width="29" height="27" border="0" align="middle" /><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("loading...");?>
</div>


  <input name="rvsMgr" type="hidden" value="target" />  
    <input name="rvsAct" type="hidden" value="edit" />
    <input name="project_page_id" id="project_page_id" type="hidden" value="" />
<table cellpadding="0" cellspacing="0" width="98%">
	<tr>
		<td align="center">
			<div id="setTargetLink">

				<table width="auto" border="0" cellspacing="4" cellpadding="0">
					
					<tr>
						<td align="right"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Name");?> :</b></td>
						<td colspan="4" align="left"><div id="pagename"><?php echo htmlspecialchars($t->project_page_name);?></div></td>
					</tr>
					<tr>
						<td align="right"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Target Link");?> :</b></td>

						<td align="left">  
								<input name="target" id="target_self" type="radio" value="_self" />
						</td>
						<td align="left"><label for="target_self"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Same Window"));?></label></td>
						<td>
							
								<input name="target" id="target_blank" type="radio" value="_blank" />
							
						</td>
						<td align="left"><label for="target_blank"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("New Window"));?></label></td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>

</form>
</div>
</div>
            