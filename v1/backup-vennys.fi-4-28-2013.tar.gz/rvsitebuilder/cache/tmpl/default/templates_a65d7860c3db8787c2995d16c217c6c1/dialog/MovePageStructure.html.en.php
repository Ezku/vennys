<?php echo $t->scriptOpen;?>
var userPageName = {};
var userPageValue = {};
    <?php if ($this->options['strict'] || (is_array($t->aPageStructureData)  || is_object($t->aPageStructureData))) foreach($t->aPageStructureData as $k => $v) {?>
    userPageName['<?php echo htmlspecialchars($k);?>'] = '<?php echo $v->page_name;?>';
    userPageValue['<?php echo htmlspecialchars($k);?>'] = '<?php echo $v->value;?>';
    <?php }?>
    
    var userPageNameInter = new Array();
    var userPageValueInter = new Array();
    var i =0;
    <?php if ($this->options['strict'] || (is_array($t->aInternalPageStructureData)  || is_object($t->aInternalPageStructureData))) foreach($t->aInternalPageStructureData as $k => $v) {?>
    userPageNameInter[i] = '<?php echo $v->page_name;?>';
    userPageValueInter[i] = '<?php echo $v->internal_page_id;?>';
    i++;
    <?php }?>
<?php echo $t->scriptClose;?>
<div id ="movePageStructure" style ="display:none">
    <div id ="movePageStructure_dialog" title ="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move page");?>">
        <div class ="dialog-option">
        modal: true,
        closeOnEscape :true,
        width: 540,
        high: 1000,
        buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Reset");?>": function() {
           jQuery.sitebuilder.listPageStructure.resetPage(jQuery(this));
        },
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Update");?>": function() {
            jQuery.sitebuilder.listPageStructure.movePageUpdate(jQuery(this));
        }
   },
   close : function() {
    jQuery('#movePageStructure-msg').html('');
    
}
        </div>
        
        <form name ="frmMovePage" method ="post" id ="frmMovePage" action="">
            <?php echo $this->elements['rvsMgr']->toHtml();?> 
           <?php echo $this->elements['rvsAct']->toHtml();?>
    
            <table boder ="0" cellspacing="0" cellpadding="0" width="100%" class="dialogPadding">
            <tr>
                <td width="50%">
                    <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page List");?>
                </td>
                <td width="50%">
                    <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Internal Page"));?>
                </td>
            </tr>
            <tr>
                <td>
                         <a class ="MovePageToInternalPage" style="cursor: pointer;">
                              <img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/step4_transfer.gif" alt="" width="19" height="19" border="0" align="texttop" />                                                                                                 
                                <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move Page");?>
                        </a> 
                 </td>
                <td>
		               <a class ="movePageToMainPage" style="cursor: pointer;">
		                      <img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/step5_movepage.jpg" alt="" width="19" height="19" border="0" align="texttop" />                                                                                                 
		                        <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move Page");?>
		                </a> 
                </td>
                  
            </tr>
            
            <tr>
                <td>
                    <table>
                    <form name="frmMainPage" id ="frmMainPage" method="post" style="padding:0px; margin:0px;">
                                                <select name="numPage[]" multiple id="numPage" size="11" class="borderSelect" style="width:230px; height:180px;">
                                                    <?php if ($this->options['strict'] || (is_array($t->aPageStructureData)  || is_object($t->aPageStructureData))) foreach($t->aPageStructureData as $k => $v) {?>
	                                                    <?php if ($v->parent_project_page_id)  {?>
	                                                   <option value="<?php echo htmlspecialchars($v->value);?>">***<?php echo $v->page_name;?></option>
	                                                    <?php } else {?>
	                                                    <option value="<?php echo htmlspecialchars($v->value);?>"><?php echo $v->page_name;?></option>
	                                                    <?php }?>
	                                                  <?php }?>                                                    
                                                </select>         
                                            </form> 

                    </table>
                </td>
                
                <td>
                    <table width>
                  
                    <form name="frmInternalPage" method="post" style="padding:0px; margin:0px;">
                                                <select name="selectPageIn[]" multiple id="selectPageIn" size="11" class="borderSelect" style="width:230px; height:180px;">
                                                    <?php if ($this->options['strict'] || (is_array($t->aInternalPageStructureData)  || is_object($t->aInternalPageStructureData))) foreach($t->aInternalPageStructureData as $k => $v) {?>
                                                    <option value="<?php echo $v->project_page_id;?>"><?php echo $v->page_name;?></option>
                                                    <?php }?>
                                                </select>         
                                            </form> 
                    </table>
                </td>

            </tr>
            </table>
        
        
        </from>
        
    <div id="btnMoveHomePage" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page up");?>" style="display:none">
    <div class="dialog-option">
    closeOnEscape :true,
    buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
            jQuery('#btnMoveHomePage').rvsDialog('close');
        }
    }
    </div>
        <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page up");?>&nbsp;.
    </div>

    <div id="btnUpIsHome" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page up");?>" style="display:none">
    <div class="dialog-option">
    closeOnEscape :true,
    buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
            jQuery('#btnUpIsHome').rvsDialog('close');
        }
    }
    </div>
        <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?><br>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Sorry, can not move up. The upper page is Home Page.");?>&nbsp;
    </div>
    
    <div id="btnMoveDown" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page down");?>" style="display:none">
    <div class="dialog-option">
    closeOnEscape :true,
    buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
            jQuery('#btnMoveDown').rvsDialog('close');
        }
    }
    </div>
     <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page down");?>&nbsp;.
    </div>

    <div id="btnMovePageToInternalPage" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move page list");?>" style="display:none">
    <div class="dialog-option">
    closeOnEscape :true,
    buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
            jQuery('#btnMovePageToInternalPage').rvsDialog('close');
        }
    }
    </div>
     <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Home Page and can not ");?>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("move page to internalpage");?>&nbsp;.
    </div>
    
    <div id="btnMainPage" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move page list");?>" style="display:none">
    <div class="dialog-option">
    closeOnEscape :true,
    buttons:{
        "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
            jQuery('#btnMainPage').rvsDialog('close');
        }
    }
    </div>
     <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("This page is Main and can not ");?>&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("update page");?>&nbsp;.
    </div>
    
   

    </div>
</div>
<div id ="msgSuccessPage" style="display:none">
  <div id="btnsuccess" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Move page list");?>">
        <div class="dialog-option">
        modal: true,
        closeOnEscape :true,
        width: 200,
        high: 5,
        </div>
     <div class="ui-state-highlight ui-corner-all" style ="diaplay:none"> 
                    <p><span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
                      <div id="success" style ="display: none;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("success");?></div>
                     </p> 
      </div>
   
    </div>
<div> 