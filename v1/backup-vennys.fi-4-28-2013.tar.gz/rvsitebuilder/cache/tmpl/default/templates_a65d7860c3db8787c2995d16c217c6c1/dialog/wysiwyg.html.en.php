<div id="wysiwygDialogStep5" style="display:none;">  
  <div id="wysiwygDialogStep5-layout" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Confirm");?>">
       <div class="dialog-option">  
closeOnEscape :true,
width:400,
height:'auto',
buttons:{
	    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
			jQuery(this).rvsDialog('close');
	    },
	     "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Yes");?>": function() {
	        jQuery.sitebuilder.wysiwyg.generateData(currentLayout, focusLayOut, focusZone, currentNumZone);
        	jQuery.sitebuilder.wysiwyg.changeLayoutActive(currentClickLayout, jQuery('#tabs-1'));
        	jQuery(this).rvsDialog('close');
	    },
	    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("No");?>": function() {
			jQuery.sitebuilder.wysiwyg.generateData(currentLayout, focusLayOut, focusZone);
			jQuery.sitebuilder.wysiwyg.changeLayoutActive(currentClickLayout, jQuery('#tabs-1'));
			jQuery(this).rvsDialog('close');
	    }
	   
	}
  </div> 
     <div id="wysiwygDialogStep5edlayout">
    
      <div class="ui-widget">
                <div class="ui-state-highlight ui-corner-all"> 
                  <span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
 					<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("A number of zones of new layout less than current layout.");?>
                </div>
                	<div style="text-align: center">
 					<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Do you want to merge original ?");?>
 					</div>
            </div> 
      </div>
</div>
</div>

<!-- start Show Msg-->
<div id ="showMsgWysi" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("step 5 Wysiwyg");?>"></div>
<div id ="msgResult" style="display:none">
<div class="ui-widget dialogPadding">
    <div class="ui-state-highlight ui-corner-all"> 
        <div><span class="ui-icon ui-icon-alert" style="float: left; margin-right: 0.3em;"></span>
            <span id="msgResult-message-success" style="display:none"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit wysiwyg is successfully");?></span>
            <span id="msgResult-message-err" style="display:none"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit wysiwyg is not success");?></span>
        </div>
    </div>
</div>
</div>
<!-- end Show Msg-->

<div id ="showMsgWaiting" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("step 5 Wysiwyg");?>" style="display:none">
<div class="ui-state-highlight ui-corner-all"> 
	<span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
 	<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please waiting process change layout.");?>
</div>
</div>

<div id="wysiwygcontenttemplate" style="display: none;">  
  <div id="wysiwygcontenttemplate-select" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please Select  Content Template");?>">
       <div class="dialog-option">  
closeOnEscape :true,
width:673,
height:360
       </div> 
        <?php 
if (!isset($this->elements['typetemplate']->attributes['value'])) {
    $this->elements['typetemplate']->attributes['value'] = '';
    $this->elements['typetemplate']->attributes['value'] .=  htmlspecialchars($t->typeTemplate);
}
$_attributes_used = array('value');
echo $this->elements['typetemplate']->toHtml();
if (isset($_attributes_used)) {  foreach($_attributes_used as $_a) {
    unset($this->elements['typetemplate']->attributes[$_a]);
}}
?>
		   
        <div id="htmlBlockDesign" style="width:97%; height:190px;">
        	<div id ="loadingwysi">
        	<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/loading02.gif" alt="" width="29" height="27" border="0" />
        	 Loading...
        	</div>
        </div>
    </div>
 </div>

<div id="wysiwygvdohelp" style="display: none;">  
  <div id="wysiwygvdohelp-select" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please Select  Wysiwyg Help");?>">
       <div class="dialog-option">  
closeOnEscape :true,
width:805,
height:645

       </div> 
           <iframe id="wysHelpFrame" src="<?php echo htmlspecialchars($t->urlHelp);?>" width="800" height="600" frameborder="0"></iframe>
      </div>
 </div>