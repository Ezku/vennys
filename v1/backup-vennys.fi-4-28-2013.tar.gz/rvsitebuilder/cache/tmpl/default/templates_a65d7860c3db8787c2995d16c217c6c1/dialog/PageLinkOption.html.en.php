<div id ="PageLinkOption-External" style="display: none;">
	<div id ="PageLinkOption_External-Link" title ="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("External Link Option");?>">
		<div class ="dialog-option">
		modal: true,
		closeOnEscape :true,
		width: 600,
		high: 400,
		buttons:{
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        jQuery(this).rvsDialog('close');
    },
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>": function() {
        	 jQuery.sitebuilder.listPageStructure.SavePageLinkOption("#pagelinkoption_page");
    }
}
,
close: function() {
 jQuery('#pagelinkoption_page-msg').html('');
  jQuery('#showMsg').html('');
 }
 
		</div>

	<div id ="pagelinkoption_page">
		<div class="ui-state-highlight ui-corner-all" style ="diaplay:none; margin:20px 20px 0px 20px;"> 
			<span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
			  <div id ="showMsg"></div>
			  <div id="pagelinkoption_page-msg"></div>
         </div>

<form method="post" name="FrmOption[]" id="FrmOption" action="">
    <?php echo $this->elements['rvsMgr']->toHtml();?> 
    <?php echo $this->elements['rvsAct']->toHtml();?>
    <input name ="project_page_id" id ="project_page_id" type ="hidden" value="">
    
<table cellpadding="0" cellspacing="0" width="98%">
	
	<tr>
		<td>
			<div class="formExternal">
			<div id="pagelinkoption_message"></div>
			<div id ="radioEnRemove" align="right">
				<span><?php 
                $element = $this->elements['FrmOption_rvs_link_enable_1'];
                if (isset($this->elements['FrmOption[rvs_link_enable]'])) {
                    $element = $this->mergeElement($element,$this->elements['FrmOption[rvs_link_enable]']);
                }
                echo  $element->toHtml();?></span>
				<span><label for="FrmOption_rvs_link_enable_1"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Enable");?></label></span>
				<span id="span_rvs_link_enable_0">
					<span><?php 
                $element = $this->elements['FrmOption_rvs_link_enable_0'];
                if (isset($this->elements['FrmOption[rvs_link_enable]'])) {
                    $element = $this->mergeElement($element,$this->elements['FrmOption[rvs_link_enable]']);
                }
                echo  $element->toHtml();?></span>
					<span><label for="FrmOption_rvs_link_enable_0"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Remove");?></label></span>
				</span>
			</div>

				<table width="99%" border="0" cellspacing="0" cellpadding="2" id="selectLink">
					<tr>
						<td class="title"><label for="url"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("External URL");?> :</label></td>
						<td style="padding-left: 5px;"><?php echo $this->elements['FrmOption[external_url]']->toHtml();?></td>
					</tr>
					<tr>
						<td class="title"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Target Link");?> :</td>
						<td valign="top"> 

							<div>
								<span><?php 
                $element = $this->elements['FrmOption_target_self'];
                if (isset($this->elements['FrmOption[target]'])) {
                    $element = $this->mergeElement($element,$this->elements['FrmOption[target]']);
                }
                echo  $element->toHtml();?>
								</span>
								<span><label for="FrmOption[target][_self]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Same Window");?></label></span>
								<span><?php 
                $element = $this->elements['FrmOption_target_blank'];
                if (isset($this->elements['FrmOption[target]'])) {
                    $element = $this->mergeElement($element,$this->elements['FrmOption[target]']);
                }
                echo  $element->toHtml();?></span>
								<span><label for="FrmOption[target][_blank]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("New Window");?></label></span>
							</div>
						</td>
					</tr>
				</table>
			</div>
			<div class="formExternal" style="padding-top:30px; margin-left:8px;">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td align="center"><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/fullsize.gif" alt="" id="img_Full" /></td>
						<td align="center"><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/customsize.gif" alt="" id="img_Custom" /></td>
					</tr>
					<tr>

						<td width="50%">
							<div class="disSelectRadio" id="div_Full" style="text-align: center;">
								<span><!-- FrmOption[fullscreen][1] onclick="displayCustomOption()"--><?php 
                $element = $this->elements['FrmOptFullscreen'];
                if (isset($this->elements['FrmOption[fullscreen]'])) {
                    $element = $this->mergeElement($element,$this->elements['FrmOption[fullscreen]']);
                }
                echo  $element->toHtml();?>
								</span>
								<span><label for="FrmOption[fullscreen][1]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Full Size");?></label></span>
							</div>
						</td>
						<td width="50%">
							<div class="selectRadio" id="div_Custom" style="text-align: center;">

								<span><!-- FrmOption[fullscreen][0] --><?php 
                $element = $this->elements['FrmOptFullscreen0'];
                if (isset($this->elements['FrmOption[fullscreen]'])) {
                    $element = $this->mergeElement($element,$this->elements['FrmOption[fullscreen]']);
                }
                echo  $element->toHtml();?></span>
								<span><label for="FrmOption[fullscreen][0]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Custom Size");?></label></span>
							</div>
						</td>
					</tr>
					<tr id="tr_customOption">
						<td colspan="2">
							<table width="100%" border="0" cellspacing="3" cellpadding="0" id="t_checkbox">

								<tr>
									<td width="30%" align="left">
										<?php echo $this->elements['FrmOption[toolbar]']->toHtml();?>
										<label for="FrmOption[toolbar]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("toolbar");?></label>									</td>
									<td width="30%" align="left">
										<?php echo $this->elements['FrmOption[location]']->toHtml();?>
										<label for="FrmOption[location]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("location");?></label>									</td>

									<td width="30%" align="left">
										<?php echo $this->elements['FrmOption[status_bar]']->toHtml();?>
										<label for="FrmOption[status_bar]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("status bar");?></label>									</td>
								</tr>
								<tr>
									<td align="left">
										<?php echo $this->elements['FrmOption[menubar]']->toHtml();?>
										<label for="FrmOption[menubar]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("menu bar");?></label>									</td>

									<td align="left">
										<?php echo $this->elements['FrmOption[scrollbars]']->toHtml();?>
										<label for="FrmOption[scrollbars]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("scrollbars");?></label>									</td>
									<td align="left">
										<?php echo $this->elements['FrmOption[resizeable]']->toHtml();?>
										<label for="FrmOption[resizeable]"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("resizeable");?></label>									</td>
								</tr>

								<tr>
									<td colspan="3" class="sizWindow">
										<div>
											<span><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Size");?> : </span>
											<span><?php echo $this->elements['FrmOption[size_width]']->toHtml();?></span> 
											<span>X</span> 
											<span><?php echo $this->elements['FrmOption[size_height]']->toHtml();?></span> 
											<span><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Pixel");?></span>
										</div>

									</td>
								</tr>
							</table>
							</div>
						</td>
					</tr>
				</table>
					</div>	
		</td>
	</tr>
</table>
</form>
	</div>
</div>
<div id="PageLinkOption_External-error" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("External Link  error");?>">
        <div align="center" style="padding-top:20px;">  
        <span id="PageLinkOption_External-messageErr"></span>
        </div>
</div>
<div id="PageLinkOption_External-success" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("External Link   success");?>">
        <div align="center" style="padding-top:20px;">  
        <span id="PageLinkOption_External-message"></span>
        </div>
</div>
</div>