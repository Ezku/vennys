<div id="windowComponentUser" style="display:none "> <!--  -->
    <div id="componentUser-Msg" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Configuration");?>">
        <div class="dialog-option">
        modal: false,
closeOnEscape :true,
buttons:{
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        jQuery(this).rvsDialog('close');
    }
}
        </div>
        <div class="ui-widget">
         <div class="ui-state-highlight ui-corner-all"> 
                    <p><span class="ui-icon ui-icon-info" style="float: left; margin-right: 0.3em;"></span>
                    <div id="listpageconfirm-content-page">
                    <div id="txtmsg"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Are you sure to delete?");?></div> 
                    </div>
                    <div id="listpageconfirm-content-msg"> </div>
                 
                    </p>
                   
                </div>
                </div>
    </div>
</div>
