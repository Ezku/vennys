<div id="extraPagetitleReset" style="display: none;">
    <div id="extraPagetitle-reset" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Reset Page Title");?>">
        <div class="dialog-option">
			modal: true,
			closeOnEscape :true,
			width: 500,
			buttons:{
			    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
			        jQuery('#extraPagetitle-reset').rvsDialog('close');
			    },
			    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Reset");?>": function() {
			        jQuery.sitebuilder.extras_Pagetitle.cmdReset("#frmTitleReset");
			    }
			}
        </div>
        
	<form name="frmTitleReset" id="frmTitleReset" action="">
		
		<input name="rvsMgr" type="hidden" value="Extras_PageTitle" /> 
    	<input name="rvsAct" type="hidden" value="reset" />
    	<input name="project_page_id" id="project_page_id" value="<?php echo htmlspecialchars($t->project_page_id);?>" type="hidden" />
    	
		<table cellpadding="0" cellspacing="0" width="98%">
			<tr>
				<td id="hidReset" align="center">
		
					<div id="setTarget" align="center">
		               <table width="auto" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td id="objTitle" align="center"> <span id="confirmDelTopic"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Name");?></b></span> : <span id="pagename"><!-- {project_page_name:h}  --></span></td>
							</tr>
							<tr>
								<td class="txtQuestion" align="center"><div id="txtConfirmDel"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Are you sure you want to reset default page title?");?></div></td>
							</tr>
						</table>
					</div>	
						
				</td>
			</tr>
		</table>
		
	</form>
	
</div>