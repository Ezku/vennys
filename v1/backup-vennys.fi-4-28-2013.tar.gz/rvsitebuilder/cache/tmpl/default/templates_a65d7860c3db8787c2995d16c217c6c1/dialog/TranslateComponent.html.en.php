<div id="dialog-translatec-component-hidden" style="display: none;">

  	<!-- component name -->
	<div id="dialog-translate-component-componentname" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("TranslateComponent Componentname");?>">
	
		<div class="dialog-option">
 			modal: true,
			closeOnEscape :false,
			width: 500,
			buttons:{}
		</div>
		
		<form name="frmCurrentComponentName" id="frmCurrentComponentName" method="post">
	    	<input name="rvsMgr" type="hidden" value="cTranslateComponent" /> 
	    	<input name="rvsAct" type="hidden" value="list" />
	        <input id="currentComponentName" name="currentComponentName" type="hidden" value="" />
	  	</form>

	</div>
	
	<!-- edit -->
	<div id="dialog-translate-component-edit" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("TranslateComponent Edit");?>">
	
		<div class="dialog-option">
			modal: true,
			closeOnEscape :false,
			width: 500,
			buttons:{}
		</div>
		
		<form name="frmEdit" id="frmEdit" method="post">
		
	    	<input name="rvsMgr" type="hidden" value="cTranslateComponent" /> 
	    	<input name="rvsAct" type="hidden" value="edit" />
	    	<input id="currentKey" name="currentKey" type="hidden" value="" />
	        <input id="keyLang" name="keyLang" type="hidden" value="" />
	        <input id="currentComponentName" name="currentComponentName" type="hidden" value="" />
	        <input id="editCurrentLang" name="editCurrentLang" type="hidden" value="" />
	        
	  	</form>
	  	
	</div>
	
	<!-- view edit -->
	<div id="dialog-translate-component-viewedit" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("TranslateComponent VeiwEdit");?>">
	
		<div class="dialog-option">
 			modal:true,
			closeOnEscape:true,
			width:500,
			buttons:{
			    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Save");?>": function() {
			    	jQuery.sitebuilder.TranslateComponent.Edit("#frmEdit");
			    }, 
			    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
			    	jQuery('#dialog-translate-component-viewedit').rvsDialog('close');
			    }
			}
		</div>
		
		<form name="frmViewEdit" id="frmViewEdit" method="post">
		
	    	<input name="rvsMgr" type="hidden" value="cTranslateComponent" /> 
	    	<input name="rvsAct" type="hidden" value="viewedit" />
	    	<input id="currentKey" name="currentKey" type="hidden" value="" />
	    	<input id="keyLang" name="keyLang" type="hidden" value="" />
	    	<input id="currentComponentName" name="currentComponentName" type="hidden" value="" />
	    	<div style="padding:20px 10px 10px 10px;">
				<table align="center" cellpadding="2" cellspacing="0">
					<tr>
						<td width="140" align="left" valign="middle"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Key");?></b></td>
						<td align="left" valign="middle"><div id="contentKeyLang" name="contentKeyLang"></div></td>
					</tr>
					<tr>
						<td align="left" valign="middle"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("English Value");?> </td>
						<td align="left" valign="middle"><div id="contentEnglishLang" name="contentEnglishLang"></div></td>
					</tr>
					<tr>
						<td align="left" valign="middle"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Default Value");?> </td>
						<td align="left" valign="middle"><div id="contentCurrentLang" name="contentCurrentLang"></div></td>
					</tr>
					<tr>
						<td align="left" valign="middle"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Custom Value");?> </td>
						<td align="left" valign="middle"><input id="editCurrentLang" name="editCurrentLang" value="" /></td>
					</tr>
				</table>
	        </div>
	    </form>
	
	</div>
	
	<!-- reset -->
	<div id="dialog-translate-component-reset" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("TranslateComponent Edit");?>">
	
		<div class="dialog-option">
			modal: true,
			closeOnEscape :false,
			width: 500,
			buttons:{}
		</div>
		
		<form name="frmReset" id="frmReset" method="post">
		
	    	<input name="rvsMgr" type="hidden" value="cTranslateComponent" /> 
	    	<input name="rvsAct" type="hidden" value="reset" />
	    	<input id="currentKey" name="currentKey" type="hidden" value="" />
	        <input id="keyLang" name="keyLang" type="hidden" value="" />
	        <input id="currentComponentName" name="currentComponentName" type="hidden" value="" />
	        
	  	</form>
	  	
	</div>
	
	<!-- status success-->
	<div id="dialog-translate-component-status-success" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("TranslateComponent Status");?>">
	
		<div class="dialog-option">
 			modal: true,
			closeOnEscape :false,
			width: 400,
			buttons:{}
		</div>
		
		<div id="dialog-translate-message-status-success" align="center">Success..</div>
	
	</div>
	
	<!-- status warning-->
	<div id="dialog-translate-component-status-warning" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please wait");?>">
	
		<div class="dialog-option">
 			modal:true,
			closeOnEscape:true,
			width:400,
			buttons:{
			    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
			    	jQuery('#dialog-translate-component-status-warning').rvsDialog('close');
			    }
			}
		</div>
		
		<div id="dialog-translate-message-status-warning" align="center"></div>
	
	</div>
	
	<!-- Wait -->
    <div id="dialog-translate-component-wait" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please wait");?>">
    
        <div class="dialog-option">
            modal: true,
            closeOnEscape :false,
            width: 400,
            buttons:{}
        </div>
        
        <div id="dialog-translate-component-wait-message" align="center"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please wait");?></div>
        
    </div>
	
</div>