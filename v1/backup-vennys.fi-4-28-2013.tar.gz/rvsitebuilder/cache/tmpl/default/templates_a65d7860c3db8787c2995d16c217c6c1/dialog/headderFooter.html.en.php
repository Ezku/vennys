<div id="headerFooter" style="display: none;">  
  <div id="headerFooter-set" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Please edit");?>">
       <div class="dialog-option">  
closeOnEscape :true,
width:800,
height:544,
beforeclose2:function(){
jQuery(this).find("#headFrame").remove()
}
  </div> 
      <div id="iframeHeaderFooter" style="width:100%"></div>
</div>
</div>
