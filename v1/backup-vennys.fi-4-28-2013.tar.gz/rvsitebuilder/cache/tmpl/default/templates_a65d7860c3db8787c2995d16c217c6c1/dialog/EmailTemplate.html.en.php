<div id="dialog-email-hidden" style="display: none;">  
  <div id="dialog-email-set" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit Config Email");?>">
       <div class="dialog-option">
       closeOnEscape :true,
			width:810,
			height:600,
			beforeclose2:function() {
				jQuery(this).find("#headFrame").remove()
			} 
  	   </div> 
      
      <!-- set iframeEmail -->
      <div id="iframeEmail" style="width:100%"></div>
	</div>

	<!-- chang  -->
	<div id="dialog-email-template-chkcomponent" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Chang Component");?> : ">
		<div class="dialog-option">
 			modal: true,
			closeOnEscape :false,
			width: 600,
			buttons:{}
		</div>
		
		<form name="frmChkComponent" id="frmChkComponent" method="post">
	    	<input name="rvsMgr" type="hidden" value="cemailtemplate" /> 
	    	<input name="rvsAct" type="hidden" value="list" />
	        <input id="componentId" name="componentId" type="hidden" value="" />
	        <input id="componentName" name="componentName" type="hidden" value="" />
	  	</form>

	</div>
	
	<!-- reset to default -->
	<div id="dialog-email-template-resettodefault" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("reset to default");?> : ">
		<div class="dialog-option">
 			modal: true,
			closeOnEscape :false,
			width: 600,
			buttons:{}
		</div>
		
		<form name="frmResetTodefault" id="frmResetTodefault" method="post">
	    	<input name="rvsMgr" type="hidden" value="cemailtemplate" /> 
	    	<input name="rvsAct" type="hidden" value="reset_to_default" />
	        <input id="getEmailTemplate" name="getEmailTemplate" type="hidden" value="" />
	        <!-- <input id="componentName" name="componentName" type="hidden" value="" />  -->
	  	</form>

	</div>
	
	<!-- show message reset to default-->
	<div id="dialog-email-template-resettodefault-status" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("reset to default");?>">
        <div align="center" style="padding-top:20px;">  
        	<span id="resettodefault-status-message"></span>
        </div>
    </div>
	
</div>