<div id="listpageconfirm" style="display:none;">  
  <div id="listpageconfirm-delete" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Title Please confirm");?>">
       <div class="dialog-option" align="center">       
closeOnEscape :true,
buttons:{
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
     jQuery(this).rvsDialog('close');
    },
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Ok");?>": function() {
      jQuery.sitebuilder.listPageStructure.DeleteListPage("#frmConfirmDelListpage");  
    }
},
close : function() {
	jQuery('#showError').html('');
	jQuery('#listpageconfirm-content-msg').html('');
	
}
      </div> 
 <div id="showError" style="display:"></div>
<div id="listpageconfirm-content" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Title Please confirm");?>">
           <div class="ui-widget dialogPadding">
                <div class="ui-state-highlight ui-corner-all"> 
                  <span class="ui-icon" style="float: left; margin-right: 0.3em;"></span>
                    <div id="listpageconfirm-content-msg"> </div>
                    <div id="listpageconfirm-content-page">
					<div id="txtConfirmDel" class="txtQuestion"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Are you sure to delete?");?></div> 
		            </div>
                   
                </div>
            </div> 
</div>

<form name="frmConfirmDelListpage" id="frmConfirmDelListpage" action="">
<div style="position:;display:none;" id="listPageConfirmDeleteLoading">
<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/loading02.gif" alt="" width="29" height="27" border="0" align="middle" /><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("loading...");?>
</div>
<div id="setTarget" align="center">
<input name="rvsMgr" type="hidden" value="listpagestructure" /> 
<input name="rvsAct" type="hidden" value="delete" />
<input name="project_page_id" id="project_page_id" type="hidden" value="" />
<div id="setTargetLink">
              <table width="auto" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td id="objTitle"> <span id="confirmDelTopic"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page Name");?></b></span> : <span id="pagename"><?php echo htmlspecialchars($t->project_page_name);?></span></td>
					</tr>
			 </table>
</div>
</div>
</form>
</div>
 </div>

 