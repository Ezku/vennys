<?php if ($t->error)  {?>
<table align="center">
    <tr>
        <td height="5">
    <!-- Display Error -->
        <?php if ($this->options['strict'] || (is_array($t->error)  || is_object($t->error))) foreach($t->error as $k => $v) {?>
            <div align="center"><br><font size="5" color="red"><?php echo $v;?></font></div>
        <?php }?>
        </td>
    </tr>
</table>
<?php }?>

<div id="sitepreview" style="display: none;"> <!--  -->
    <div id="sitepreview-mainprocess" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Preview");?>: <?php echo htmlspecialchars($t->project_name);?>">
        <div class="dialog-option">
modal: true,
closeOnEscape :true,
width :550,
height :500,
buttons:{
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Cancel");?>": function() {
        jQuery('#sitepreview_step1').rvsDialog('close');
        window.close(); 
    }
}
        </div>
		<div class="dialogPadding">
			<form id="preview-project-form" method="post">
				<input id="rvsMgr" name="rvsMgr" type="hidden" value="SitePreview" />  
				<input id="rvsAct" name="rvsAct" type="hidden" value="startpreviewprocess" />  
				<div class="ui-widget">
					<div id="message_preview_project" style="padding-bottom:8px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Preview project name");?>: <b><?php echo htmlspecialchars($t->project_name);?></b></div>
					<div class="ui-state-highlight ui-corner-all"> 
						<div id="notice">
							<!--<span class="ui-icon ui-icon-notice" style="float: left; margin-right: 0.3em;"></span>-->
							<img class="SPicon SPs6_warning_s2" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="18" height="16" border="0" align="absmiddle" />&nbsp;&nbsp;<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("We are building the preview mode of your web site. This will not overwrite your live web site");?>
						</div>
					</div>
					<div id="message" class="message_publish"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Preparing data. Please wait...");?></div>
					<!-- debug only
					<div id="debug" style="padding-left:35px;"></div>
					-->
				</div>      
			</form>
		</div>
    </div>
    
    <div id="sitepreview-error" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Error");?>">
        <div class="dialog-option">
modal: true,
closeOnEscape :false,
buttons:{
    "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Close");?>": function() {
        jQuery('#sitepreview-error').rvsDialog('close');
        window.close(); 
    }
}
        </div>
        <div class="ui-widget">
            <div class="ui-state-error"> 
                <div id="error">
                    <span class="ui-icon ui-icon-alert" style="float: left; margin-right: 0.3em;"></span>
                    <div id="message" class="ui-state-error-text"></div>
                </div>
            </div>
             
        </div>      
    </div>
</div>
