
<table cellspacing="0" cellpadding="0" width="100%">
	<tr>
		<td align="left" valign="top"><!--Start Website Structure -->
			<div class="title">
				<div class="left"><span><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page List");?></span></div>
				<div class="right">
					<span class="inlinehelp"> 
						<img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" /> 
						<span>	<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Internal Page","vprintf","SB_IMG_URL|SB_IMG_URL");?></span>
					</span>
				</div>
				<div class="clearit"></div>
			</div>
			
			<div class="padding">
				<div>
					<input name="button" type="button" class="btnStructure" id="webpagestructure" mgr="ListPageStructure" act="master_and_internalpage" targetact="rvDisplayMain" value=" <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Website Structure"));?>" />
				</div>
				<form method="post" id="FrmAddInternalPage" name="FrmAddInternalPage" action="">
					<div align="left"><b><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Add Internal Page");?></b></div>
					<div align="left">
						<input type="hidden" name="rvsMgr" value="ListPageStructure" /> 
						<input type="hidden" name="rvsAct" value="add" /> 
						<input type="hidden" name="actionAdd" value="true" /> 
						<input name="page_name" type="text" id="page_name" size="20" value="<?php echo $t->page_name;?>" style="width: 140px;" />
						<input type="button" name="submit_add" id="submit_addInternalpage" value=" <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Add");?>" targetact="displayInternalPage" class="btnAdd" />
					</div>
				</form>
			</div>

			<div class="title" style="padding-top: 10px;">
				<div class="left"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Component Manage");?></div>
				<div class="right">
					<span class="inlinehelp">
						<img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" /> 
						<span style="margin-top: 0px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Manage","vprintf","SB_IMG_URL|SB_IMG_URL");?></span> 
					</span>
				</div>
				<div class="clearit"></div>
			</div>
			<div id="iconcomponent">
				<form action="" id="frmDisplayComponentConfig" method="post">
					<input type="hidden" name="rvsMgr" value="componentconfiguser" /> 
					<input type="hidden" name="rvsAct" value="list" /> 
					<input type="hidden" name="menuName" value="Configuration" /> 
					<input type="hidden" name="component_name" id="component_name" value="" /> 
					<input type="hidden" name="project_page_id" id="project_page_id" value="" />
				</form>
				<div id="swTabTarget">
					<div id="accordion" style="visibility: hidden; padding: 0; margin-top: -4px; border: 0;">
					<?php if ($this->options['strict'] || (is_array($t->aComponentMenu)  || is_object($t->aComponentMenu))) foreach($t->aComponentMenu as $kmenu => $vmenu) {?>
						<h1>
							<a href="javascript:void(0)" id="id<?php echo htmlspecialchars($vmenu->pageData->component_name);?>" component_name="<?php echo htmlspecialchars($vmenu->pageData->component_name);?>" project_page_id="<?php echo htmlspecialchars($vmenu->pageData->component_name);?>DefaultPageID" targetact="rvDisplayMain" class="icon_compo icon<?php echo htmlspecialchars($vmenu->pageData->component_name);?>" setclass="icon_compo icon<?php echo htmlspecialchars($vmenu->pageData->component_name);?>"><?php echo $vmenu->menuname;?></a>
						</h1>
						<div id="swTab<?php echo htmlspecialchars($kmenu);?>" style="display: ; padding: 0; margin: 0; border: 0;" class="ui-accordion-subtitle titleList jq_swTab">
							<div style="border: 0;">
								<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) if (!$this->plugin("isComponantAndUserFramework",$vmenu->pageData->component_name)) { ?><div>
									<a component_name="<?php echo htmlspecialchars($vmenu->pageData->component_name);?>" project_page_id="<?php echo htmlspecialchars($vmenu->pageData->component_name);?>DefaultPageID" targetact="rvDisplayMain" class="subAdcon jq_show_component" setclass="subAdcon jq_show_component"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Configuration");?></a>
								</div><?php }?>
								<?php echo $vmenu->menuCode;?>
							</div>
							<form action="" id="frmHeaderAndFooter<?php echo htmlspecialchars($vmenu->pageData->component_name);?>" method="post">
								<input type="hidden" name="rvsMgr" value="ComponentHeaderAndFooter" /> 
								<input type="hidden" name="rvsAct" value="view" /> 
								<input type="hidden" name="component_name" id="component_name" value="<?php echo htmlspecialchars($vmenu->pageData->component_name);?>" /> 
								<input type="hidden" name="project_page_id" id="project_page_id" value="<?php echo htmlspecialchars($vmenu->pageData->component_name);?>DefaultPageID" />
							</form>
							<form action="" name="frmComponent<?php echo htmlspecialchars($vmenu->pageData->component_name);?>" id="frmComponent<?php echo htmlspecialchars($vmenu->pageData->component_name);?>" method="post">
								<input type="hidden" name="rvsMgr" id="rvsMgr" value="" /> 
								<input type="hidden" name="rvsAct" id="rvsAct" value="list" /> 
								<input type="hidden" name="component_name" id="component_name" value="" /> 
								<input type="hidden" name="menuName" id="menuName" value="" /> 
								<input type="hidden" name="project_page_id" id="project_page_id" value="" />
								<input type="hidden" name="templatecustom" id="templatecustom" value="" />
								<input type="hidden" name="projectPageUserAndSystem" id="projectPageUserAndSystem" value="<?php echo htmlspecialchars($t->projectPageUserAndSystem);?>" />
							</form>
						</div>
						
					<?php }?>
					<!--{foreach:aGropComponentMenu,kCom,vCom}
					<h3>
					<a href="#" id="id{vCom[component_name]}" 
                                component_name="{vCom[component_name]}"
                                project_page_id="{vCom[component_name]}DefaultPageID"
                                targetact="rvDisplayMain"
                                class="icon_compo icon{vCom[component_name]}"
                                setclass="icon_compo icon{vmenu.pageData.component_name}">{vCom[menu_name]:h}</a>
                        </h3>
						<div id="swTab{kmenu}" style="display: ; padding: 0; margin: 0; border: 0px;" class="titleList jq_swTab">
                            <div style="padding: 0; margin: 0; border: 0px;"  
                                flexy:if="!this.plugin(#isComponantAndUserFramework#,vmenu.pageData.component_name)">
                                <a component_name="{vmenu.pageData.component_name}" 
                                    project_page_id="{vmenu.pageData.component_name}DefaultPageID"
                                    targetact="rvDisplayMain" 
                                    class="subAdcon jq_show_component"
                                    setclass="subAdcon jq_show_component">{translate(#Configuration#):h}</a>
                            </div>
                            <div>{vmenu.menuCode:h}</div>
					{end:}-->
					
					<?php if ($t->aGropComponentMenu)  {?>
                        <?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo $this->plugin("showUserMenu",$t->aGropComponentMenu);?>
					<?php }?>
					</div>
					<br />
		</div>
<!-- 
		<div class="title" style="padding-top: 10px;">
			<div class="left"><span>{translate(#Asset library#):h}</span></div>
			<div class="right">
				<span class="inlinehelp"> 
					<img class="SPicon SPtooltiphelp" src="{webRoot}/themes/{theme}/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" /> 
					<span>{translate(#help Asset library#,#vprintf#,#SB_IMG_URL|SB_IMG_URL#):h}</span> 
				</span>
			</div>
			<div class="clearit"></div>
		</div>
		<div>
-->
			<div class="title" style="padding-top: 10px;">
				<div class="left"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Asset library");?></div>
				<div class="right">
					<span class="inlinehelp">
						<img class="SPicon SPtooltiphelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" /> 
						<span style="margin-top: 0px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Asset library","vprintf","SB_IMG_URL|SB_IMG_URL");?></span> 
					</span>
				</div>
				<div class="clearit"></div>
			</div>
			<div id="iconasset">
				<div id="swTabTarget">
					<!-- div id="accordion" style="visibility: hidden; padding: 0; margin: 0;" -->
					
					<!-- BEGIN :: FORM Componect -->
						
						<div class="icon_asset iconFormOnline" setclass="icon_asset iconFormOnline"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Form");?></div>
						<div id="swTabFormOnline" style="display: ; padding: 0; margin: 0; border: 0px;" class="titleList jq_swTab">
							<div style="padding: 0; margin: 0; margin-top: -12px; border-top: 1px solid #efefef;">
								<a style="border-top: 1px solid #fff;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Form");?></a>
							</div>
							<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('formOnlineMaster.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
						<!-- /div -->
						<!-- END :: FORM Componect -->
			<!-- 
			<div>
				<a href="#" id="" component_name="" project_page_id="DefaultPageID" targetact="rvDisplayMain"
				class="icon_compo icon" setclass="icon_compo icon">Form</a>
			</div>

			<div id="pageForm" style="padding: 0; margin: 0; border: 0px;">
				<a component_name="" targetact="rvDisplayMain" 	class="subAdcon jq_show_component " setclass="subAdcon jq_show_component ">{translate(#form#):h}</a>
			</div>

			<div style="padding: 0; margin: 0; border: 0px;">
				<a component_name="xxxxxx" project_page_id="xxxxxxxxxxDefaultPageID" targetact="rvDisplayMain" class="subAdcon jq_show_component"
				setclass="subAdcon jq_show_component">{translate(#translation#):h}</a>
			</div>
			-->
		</div>
		</div>
		
		<br />
		<br />
		</td>
	</tr>
</table>

<!--   script snapshort config -->
<script type="text/javascript">
var scrollPass='N';
var wezonePass='N';
//var timeLoop=5000;
var autoSet;


function autoScroll(){
	ScrollArrow('right','webuy-toolbar','webuy-scroller','files-tab');

}
function autoScroll2(){
	ScrollArrow('right','modeling-toolbar','modeling-scroller','sites-pane');

}
function stopScroll(t,n){
		if (t=='y') { 
				//clearTimeout(autoSet);
		}else{
				fname='autoScroll'+n+'()';	
		}
}
</script>
<!-- end script snapshort config-->
