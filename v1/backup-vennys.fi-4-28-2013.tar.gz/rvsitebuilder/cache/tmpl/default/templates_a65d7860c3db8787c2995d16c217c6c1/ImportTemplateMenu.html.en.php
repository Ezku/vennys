<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if ($t->isAdmin()) { ?>
<br />
<div align="center">
<table cellpadding="0" cellspacing="0" width="100%">
	<tr align="center">
		<td>
			<a class="templatelink" href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","uploadtemplate","sitebuilder"));?>parent/1/<?php echo htmlspecialchars($t->hashKey);?>" onclick="Javascript:bSubmitted=true;">
				<img src="<?php echo htmlspecialchars($t->webThemeUrl);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/importParentTemplate.gif" border="0">
				<br />
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import Parent Template");?>
			</a>
		</td>
		<td>
			<a class="templatelink" href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","uploadtemplate","sitebuilder"));?>parent//<?php echo htmlspecialchars($t->hashKey);?>" onclick="Javascript:bSubmitted=true;">
				<img src="<?php echo htmlspecialchars($t->webThemeUrl);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/importChildTemplate.gif" border="0">
				<br />
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Import Child Template");?>
			</a>
		</td>
		<td>
			<a class="templatelink" href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","editdeletetemplate","sitebuilder"));?><?php echo htmlspecialchars($t->hashKey);?>" onclick="Javascript:bSubmitted=true;">
				<img src="<?php echo htmlspecialchars($t->webThemeUrl);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/editDeleteTemplate.gif" border="0">
				<br />
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit/Delete Template");?>
			</a>
		</td>
		    <?php if ($t->internalImport)  {?>
		    <?php } else {?>
			<td>
				<a class="templatelink" href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","admindownloadtemplate","sitebuilder"));?><?php echo htmlspecialchars($t->hashKey);?>" onclick="Javascript:bSubmitted=true;">
					<img src="<?php echo htmlspecialchars($t->webThemeUrl);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/downloadTemplate.gif" border="0">
					<br />
					<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Download Template");?>
				</a>
			</td>
			<?php }?>
						<td>
			<a class="templatelink" href="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","admintemplatecategory","sitebuilder"));?>parent/1/<?php echo htmlspecialchars($t->hashKey);?>" onclick="Javascript:bSubmitted=true;">
				<img src="<?php echo htmlspecialchars($t->webThemeUrl);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/importParentTemplate.gif" border="0">
				<br />
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Custom Category");?>
			</a>
		</td>
	</tr>
</table>
</div>
<?php }?>