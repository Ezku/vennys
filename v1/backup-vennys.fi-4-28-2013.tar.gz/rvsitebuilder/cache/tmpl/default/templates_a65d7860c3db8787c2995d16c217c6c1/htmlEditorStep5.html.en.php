<div style="<?php echo htmlspecialchars($t->bodyTemplateStyle);?>; height:800px;width:99.2%; overflow: auto;position:absolute;">

<?php echo $t->aWygPreBody;?>

    <!--open layout wysiwyg -->
<?php echo $t->aWygPostBody;?>


</div>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('scriptWysiwygStep5.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>