
<?php echo $t->scriptOpen;?>
var managerurl = "<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'makeUrl'))) echo htmlspecialchars($t->makeUrl("","listpagestructure","sitebuilder"));?>";
<?php if ($this->options['strict'] || (is_array($t->aComponentMenu)  || is_object($t->aComponentMenu))) foreach($t->aComponentMenu as $kComponentName => $vObjData) {?>
var <?php echo htmlspecialchars($kComponentName);?>DefaultPageID = '<?php echo htmlspecialchars($vObjData->pageData->project_page_id);?>';
var statusSave = true;
var bSubmitted = true;

/*photoalbum*/

var txtHConfirmSave = '<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Confirm Save PhotoAlbum");?>';
var txtConfirmSave = '<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Do you want to save");?>';
var noFolderNoAlbum = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","photo album no image or folder"));?>";
var noFolder        = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","You can create new folder by selecting \"Upload Images\" from the left menu."));?>";

var dscDelFolder = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Are you sure to delete all image and subfolder inside this folder view:"));?>";
var dscDelimg = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","Are you sure to delete?"));?>";
var imagesgallery = "<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("translateJsMsg","images"));?>";

/*end photoalbum*/
<?php }?>
<?php echo $t->scriptClose;?>
<div style="display:none;">
<input type="text" id="testUrl" size=100>
<?php echo $this->elements['testInner']->toHtml();?>
<input type="button" onclick="test()">
</div>
<table width="100%" cellspacing="1" cellpadding="0">
	<tr valign="top">
		<td align="left" valign="top" class="step5MainMenu" width="235">
		<div class="step5bgmenu"><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="235" height="23" /></div>
		<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('ListPageStructureMenu.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>		
		</td>
		<td id="line" align="left" valign="top" width="1"><img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/step5line.gif" alt="" width="1" height="23" /></td>
		<td align="left" valign="top" style="background-color:#FFFFFF;">
			<div id="mainpage" style="background-color:#FFFFFF;">
				<!-- Start Include select icon -->
					<!-- Start Display Error -->
							<div id ="rvDisplayMsgUserComponent" align="center" style="background-color:#FFFFFF;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'msgGet'))) if ($t->msgGet()) { ?><span><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'msgGet'))) echo $t->msgGet();?></span><?php }?></div>
					    <!-- End Display Error -->
	
						<!-- Start Warning -->
						<div id="rvDisplayErrorUserComponent">
							<?php if ($t->error)  {?>
								<table border="0" cellspacing="0" cellpadding="0" class="errorStep2" align="center">
									<tr><td><ul>
											<?php if ($this->options['strict'] || (is_array($t->error)  || is_object($t->error))) foreach($t->error as $k => $v) {?>
												<li><?php echo $v;?></li>
											<?php }?>
									</ul></td></tr>
								</table>
							<?php }?>
							<?php if ($t->errorcopy)  {?>
                                <table border="0" cellspacing="0" cellpadding="0" class="errorStep2" align="center">
                                    <tr><td><ul>
                                            <?php if ($this->options['strict'] || (is_array($t->errorcopy)  || is_object($t->errorcopy))) foreach($t->errorcopy as $k => $v) {?>
                                                <li><?php echo $v;?></li>
                                            <?php }?>
                                    </ul></td></tr>
                                </table>
                            <?php }?>							</div>
					     <!-- End Warning Error -->
				
			
				<!-- End Include select icon -->
				<div id ="loadingstep5" style="position: absolute; display:none;">
					<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/loading02.gif" alt="" width="29" height="27" border="0" /> Loading...</div>
				
				<div id="rvDisplayMain">
				<!-- Validate display output listpagestructure template -->
				<?php if ($t->displayMainPageStructure)  {?>
					<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('mainPageStructure.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
				<?php }?>
				</div>
			</div>		
		</td>
	</tr>
				
</table>         
        
<div id="log"></div>
<div id="TargetTemplate" style="display:none"><?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/Target.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?></div>
<div id="ListPageConfirmDelete" style="display:none"><?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/ListPageConfirmDelete.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?></div>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/PageLinkOption.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/PageLinkActive.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/MovePageStructure.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/ComponentConfigUser.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/headderFooter.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/EmailTemplate.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/TranslateComponent.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/LoginTemplate.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
<?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/rvsPhotoGallery.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
