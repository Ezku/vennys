<?php echo $t->scriptOpen;?>

	 window.name = "testWindowName";
	 <?php if ($this->options['strict'] || (is_array($t->aPageStructureData)  || is_object($t->aPageStructureData))) foreach($t->aPageStructureData as $k => $v) {?>
	 var newwin<?php echo htmlspecialchars($v->project_page_id);?> = false;
	 var newwinhtml<?php echo htmlspecialchars($v->project_page_id);?> = false;

	<?php }?>
	
<?php echo $t->scriptClose;?>
		
		<table width="100%" id ="mainTable" border="0" cellspacing="0" cellpadding="0" class="mainTable mainBorder">
			<tr>
				<td class="head" width="40%"><div align="left"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page List");?></div></td>
				<td width="10%" nowrap="nowrap" class="head"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("External Link");?>
					<span class="inlinehelp" onmouseover="this.className='inlinehelpOver';" onMouseOut="this.className='inlinehelp';"> <img class="SPicon SPhelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" />
					<span><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help External Link");?></span>
				</span>
				</td>
				<td width="10%" nowrap="nowrap" class="head">
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Edit");?>
				<span class="inlinehelp" onmouseover="this.className='inlinehelpOver';" onMouseOut="this.className='inlinehelp';"> <img class="SPicon SPhelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" />
					<span><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help WYSIWYG");?></span>
				</span>
				</td>
				<td width="10%" nowrap="nowrap" class="head">
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("HTML Code");?>
				<span class="inlinehelp" onmouseover="this.className='inlinehelpOver';" onMouseOut="this.className='inlinehelp';"> <img class="SPicon SPhelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" />
					<span style="margin:0 0 0 -80px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help HTML Code");?></span>
				</span>
				</td>
				<td width="10%" nowrap="nowrap" class="head">
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Target Link");?>
				<span class="inlinehelp" onmouseover="this.className='inlinehelpOver';" onMouseOut="this.className='inlinehelp';"> <img class="SPicon SPhelp" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" alt="" width="16" height="16" border="0" align="absmiddle" />
					<span style="margin:0 0 0 -260px;"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("help Link Target");?></span>
				</span>
				</td>
				<td width="10%" nowrap="nowrap" class="head">
				<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Last Modified");?>
				</td>
				<td width="10%" nowrap="nowrap" class="head"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Delete");?></td>
		</tr>	
			
		<!-- {aPageStructureData:r} -->
		<?php if ($this->options['strict'] || (is_array($t->aPageStructureData)  || is_object($t->aPageStructureData))) foreach($t->aPageStructureData as $k => $v) {?>	
		<?php if ($v->page_status)  {?>
		
		<tr id="tr_<?php echo htmlspecialchars($v->project_page_id);?>" class="masterpage" setSelectValue ="<?php echo htmlspecialchars($v->value);?>" setPAgeName ="<?php echo htmlspecialchars($v->page_name);?>">
		<!-- <td class="{v.classTDTop}">{v.page_name}</td>  -->
		<!-- Start Display Page Name -->
			<?php if ($v->parent_project_page_id)  {?>
				<!-- Sub page -->
			<td class="<?php echo htmlspecialchars($v->classTDTop);?>" width="40%"><div class="sub" align="left"><?php echo htmlspecialchars($v->page_name);?></div></td>
			<?php } else {?>                                     	
				<?php if ($v->isMasterPage)  {?>
					<!-- Master page --><!-- add icon hide Icon step 5  add {v.project_page_id:h} ***-->
				<td class="<?php echo htmlspecialchars($v->classTDTop);?>" width="40%"><div class="master" align="left"><?php echo htmlspecialchars($v->page_name);?>
					<?php if ($v->subPage)  {?>
							<a class ="jq_mainpage" project_page_id ="<?php echo htmlspecialchars($v->project_page_id);?>" rvs_link_id ="<?php echo htmlspecialchars($v->rvs_link_id);?>"> 
								<img id="img_mainpage" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/btnHideShortcut01.gif" width="10" height="10" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Link active"));?>" style="cursor:pointer" border="0">
							 </a>
				  <?php } else {?>
                    <?php if ($v->link_active)  {?>
					   <a class ="jq_mainpage" project_page_id ="<?php echo htmlspecialchars($v->project_page_id);?>" rvs_link_id ="<?php echo htmlspecialchars($v->rvs_link_id);?>"> 
                                <img id="img_mainpage" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/btnHideShortcut01.gif" width="10" height="10" title="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Link active"));?>" style="cursor:pointer" border="0">
                             </a>
					
					<?php }?>			   
				  <?php }?>
				   
			   </div>
				</td>
				<?php } else {?>
					<!-- Main page -->
				 <td class="<?php echo htmlspecialchars($v->classTDTop);?>" width="40%"><div class="main" align="left"><?php echo htmlspecialchars($v->page_name);?></div></td>
				<?php }?>
			<?php }?>
		<!-- End Display Page Name -->
			
			<!-- Show link.gif or nonlink.gif -->
			<?php if ($v->home)  {?>
				<!-- Disable External Link IF Home Page -->
				<td class="<?php echo htmlspecialchars($v->classTD2);?>">&nbsp;</td>
			<?php } else {?>
			
			<td class="<?php echo htmlspecialchars($v->classTD2);?>">
				<?php if ($v->link_active)  {?>
						<div id="img_link_<?php echo htmlspecialchars($v->project_page_id);?>" style="display:none">
					 <?php if ($v->rvs_link_id)  {?> 
						<div id="img_link_<?php echo htmlspecialchars($v->project_page_id);?>">
						<img id="img_linkedit_<?php echo htmlspecialchars($v->project_page_id);?>" staAct ="edit" ppid="<?php echo htmlspecialchars($v->project_page_id);?>" class="SPicon SPtargetlink jq_SPlink" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="21" height="15" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("New Option"));?>" style="cursor:pointer" border="0">
					<?php } else {?>
						 <div id="img_link_<?php echo htmlspecialchars($v->project_page_id);?>">
						<img id="img_linkedit_<?php echo htmlspecialchars($v->project_page_id);?>" staAct ="add" ppid="<?php echo htmlspecialchars($v->project_page_id);?>" class="SPicon SPtargetnonlink jq_SPnonlink" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="21" height="15" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("New Option"));?>" style="cursor:pointer" border="0">    
				   <?php }?>   
						</div>
				<?php } else {?>
					<?php if ($v->rvs_link_id)  {?> 
					   <div id="img_link_<?php echo htmlspecialchars($v->project_page_id);?>">
					   <img id="img_linkedit_<?php echo htmlspecialchars($v->project_page_id);?>" staAct ="edit" ppid="<?php echo htmlspecialchars($v->project_page_id);?>" class="SPicon SPtargetlink jq_SPlink" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="21" height="15" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("New Option"));?>" style="cursor:pointer" border="0">
					<?php } else {?>
					   <div id="img_link_<?php echo htmlspecialchars($v->project_page_id);?>">
						<img id="img_linkedit_<?php echo htmlspecialchars($v->project_page_id);?>" staAct ="add" ppid="<?php echo htmlspecialchars($v->project_page_id);?>" class=" SPicon SPtargetnonlink jq_SPnonlink" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="21" height="15" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("New Option"));?>" style="cursor:pointer" border="0">    
				   <?php }?>	
					   </div>
				 <?php }?>
			</td>
			
			<?php }?>
			
			<!-- SubPage Check Show edit WYSIWYG icon --> 
			
			<?php if ($v->showwysiwyg)  {?>
					<td class="<?php echo htmlspecialchars($v->classTDMid);?>">
				<?php if ($v->link_active)  {?>
					<div id="wysiwyg_<?php echo htmlspecialchars($v->project_page_id);?>" style="display:none">
				<?php } else {?>
					<?php if ($v->rvs_link_id)  {?>
					<div id="wysiwyg_<?php echo htmlspecialchars($v->project_page_id);?>">
					<?php } else {?>
					<div id="wysiwyg_<?php echo htmlspecialchars($v->project_page_id);?>">
					<?php }?>
				<?php }?>
				
					<a href="<?php echo $t->sgl_path_url;?>/<?php echo htmlspecialchars($t->index_phpsu);?>/sitebuilder/wysiwyg/project_page_id/<?php echo htmlspecialchars($v->project_page_id);?>" target ="windowsName<?php echo htmlspecialchars($v->project_page_id);?>" onclick="return jQuery.sitebuilder.sitebuilder.switchNewWin('newwin<?php echo $v->project_page_id;?>');">     
				<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/i-edit.gif" width="52" height="20" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Edit"));?>" border="0">
				
				</a>
						
					</td>
					</div>
			<?php } else {?>
					<td class="<?php echo htmlspecialchars($v->classTDMid);?>">
			 <?php if ($v->link_active)  {?>
				 <div id="wysiwyg_<?php echo htmlspecialchars($v->project_page_id);?>" style="display:none">
			 <?php } else {?>
				<?php if ($v->rvs_link_id)  {?>
					<div id="wysiwyg_<?php echo htmlspecialchars($v->project_page_id);?>" style="display:none">
				<?php } else {?>
					<div id="wysiwyg_<?php echo htmlspecialchars($v->project_page_id);?>">
				<?php }?>
			  <?php }?>
			  <?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) if ($this->plugin("getPageType",$v->page_type)) { ?>
				<form action="" id="frmDisplayLoginTemplate" method="post">
	            <input type="hidden" name="rvsMgr" value="cLoginTemplate">
	            <input type="hidden" name="rvsAct" value="list">
	            <input type="hidden" name="menuName" value="Login Template">
	            <input type="hidden" name="component_name" id="component_name" value="">
	            <input type="hidden" name="project_page_id" id="project_page_id" value="">
	            </form> 
				
			     <a href="javascript:" class="jq_LinkLoginTemplate" component_name ="<?php echo htmlspecialchars($v->component_name);?>" project_page_id ="<?php echo htmlspecialchars($v->component_name);?>DefaultPageID = '<?php echo htmlspecialchars($v->project_page_id);?>'" targetact ="rvDisplayMain">  
			  <?php } else {?>
			     <a href="javascript:" class="jq_CompoLink" component_name ="<?php echo htmlspecialchars($v->component_name);?>" project_page_id ="<?php echo htmlspecialchars($v->component_name);?>DefaultPageID = '<?php echo htmlspecialchars($v->project_page_id);?>'" targetact ="rvDisplayMain">
			  <?php }?>
                	<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/i-manage.gif" width="17" height="15" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Manage"));?>" border="0"></a>
						</div>
					</td>
			<?php }?>

			<!-- SubPage HTML Code -->		
			<!-- {v.showwysiwyg}	 -->		
			<?php if ($v->showwysiwyg)  {?>
					<td class="<?php echo htmlspecialchars($v->classTDMid);?>">
				 <?php if ($v->link_active)  {?>
					<div id="html_<?php echo htmlspecialchars($v->project_page_id);?>" style="display:none">
				 <?php } else {?>
					<?php if ($v->rvs_link_id)  {?>
						<div id="html_<?php echo htmlspecialchars($v->project_page_id);?>" style="display:none">
					<?php } else {?>
						<div id="html_<?php echo htmlspecialchars($v->project_page_id);?>">
					<?php }?>
				<?php }?>
							 <a href="<?php echo $t->sgl_path_url;?>/<?php echo htmlspecialchars($t->index_phpsu);?>/sitebuilder/wysiwyg/project_page_id/<?php echo $v->project_page_id;?>/htmlcode/1" target ="windowsNamehtml<?php echo htmlspecialchars($v->project_page_id);?>" onclick="return jQuery.sitebuilder.sitebuilder.switchNewWin('newwinhtml<?php echo $v->project_page_id;?>');">
							<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/htmlcode.gif" width="30" height="20" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Edit"));?>" border="0"></a>
					</div>
					</td>								
			<?php } else {?>
				 <td class="<?php echo htmlspecialchars($v->classTDMid);?>">
				 <?php if ($v->link_active)  {?>
					<div id="html_<?php echo htmlspecialchars($v->project_page_id);?>" style="display:none">
				 <?php } else {?>
					<div id="html_<?php echo htmlspecialchars($v->project_page_id);?>">
				 <?php }?>
				 &nbsp;</div></td>
			<?php }?>
			
			<!-- SubPage Show Target Amarin Not Complete -->														
			<?php if ($v->target)  {?>
					<td class="<?php echo htmlspecialchars($v->classTDMid);?>">
				 <?php if ($v->link_active)  {?>
					<div id="targetlink_<?php echo htmlspecialchars($v->project_page_id);?>" style="display:none">
				 <?php } else {?>
					<?php if ($v->rvs_link_id)  {?>
						<div id="targetlink_<?php echo htmlspecialchars($v->project_page_id);?>" style="display:none">
					<?php } else {?>
						<div id="targetlink_<?php echo htmlspecialchars($v->project_page_id);?>">	
					<?php }?>
				 <?php }?>
					<a class ="jq_targetLink" pagename ="<?php echo htmlspecialchars($v->page_name);?>" project_page_id ="<?php echo htmlspecialchars($v->project_page_id);?>">
						<img src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/<?php echo htmlspecialchars($v->targetPic);?>" id="linkTarget_<?php echo htmlspecialchars($v->project_page_id);?>" width="15" height="15" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Edit"));?>" style="cursor:pointer" border="0"></a>
					 </a>
					 </div>
					</td>
			
			<?php }?>
			
			<td class="<?php echo htmlspecialchars($v->classTDMid);?> txt10n">
				<?php if ($v->last_modifier)  {?>
					<?php if ($this->options['strict'] || (isset($this) && method_exists($this, 'plugin'))) echo htmlspecialchars($this->plugin("getFormatTime",$v->last_modifier));?>
				<?php } else {?>
					....
				<?php }?>
			</td>
			
			<!-- SubPage Show Delete icon -->
			<td class="<?php echo htmlspecialchars($v->classTDBot);?>">
		
				 <?php if ($v->home)  {?>
					&nbsp;
				 <?php } else {?>
						<!-- not show delete icon in component use db -->
						<?php if (!$v->rvs_component_id)  {?>
						
						<a class ="jq_DeleteListPage" pagename ="<?php echo htmlspecialchars($v->page_name);?>" project_page_id ="<?php echo htmlspecialchars($v->project_page_id);?>">	
					   <img class="SPicon SPdel_wys" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="19" height="18" alt="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo htmlspecialchars($t->translate("Delete"));?>" style="cursor:pointer" border="0"> 
						</a>		

					   <?php } else {?>	              					   		
							&nbsp;	              					   		
					   <?php }?>
				<?php }?>
			</td>
			
			<!-- SubPag Check Show manage icon -->
			
		</tr>
		
		<?php }?>
		<?php }?>
</table>