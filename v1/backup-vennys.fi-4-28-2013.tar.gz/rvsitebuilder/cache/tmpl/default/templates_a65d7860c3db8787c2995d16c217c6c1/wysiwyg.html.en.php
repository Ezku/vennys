<!-- New design  --> 
<div style="background-color:#e8e8e8;">
<div style ="display:none;" id="masterori"><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'loadBlocks'))) echo $t->loadBlocks("","WysiwygPro","editorMaster",$t->aPef);?></div>
<div id="PageHelpWysiwyg" style="display:none;"></div> 
<table cellpadding="0" cellspacing="0" border ="0" bordercolor="red" width="100%" class="bgPageNameWYSI"><tr>
<td width="33%"> <?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('wysiwygAllowScript.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?></td>
<td width="33%"><div class="bgPageNameWYSI"><center><?php echo $t->pageName;?></center></div></td>
<td width="33%" align="right" style="padding-right:20px;padding-top:3px;">
 <a id="setGotoStep5" class="btn_wysback"><img border="0" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="24" height="22" /></a><a id="closeWin" class="btn_wysclose"><img border="0" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/spacer.gif" width="24" height="22" /></a>

 
</td>
</tr></table>
    <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'isAdmin'))) if (!$t->isAdmin()) { ?>
    <script type="text/javascript">jQuery.sitebuilder.sitebuilder.addwarning();</script>
    <?php }?>
<div class="wproEditor" style="background-color:#e8e8e8;color:black;">
    <div id="rvtoolBarWysiwyg" class="" style="height:70px;">
        <div id="RVeditorZone1_designToolbar" class="wend"></div>
        <div id="RVeditorZone2_designToolbar" class="wend"></div>
        <div id="RVeditorZone3_designToolbar" class="wend"></div>
        <div id="RVeditorZone4_designToolbar" class="wend"></div>
        
        <div id="RVeditorZone1_sourceToolbar" class="wend"></div>
        <div id="RVeditorZone2_sourceToolbar" class="wend"></div>
        <div id="RVeditorZone3_sourceToolbar" class="wend"></div>
        <div id="RVeditorZone4_sourceToolbar" class="wend"></div> 
    </div>
     

  <div id="tabs" style="position:absolute;z-index:100;display: none;width:99%">      
        <ul>
            <li><a href="#tabs-1"><span id="contentPageLayout" class='tabActive'><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Page layout");?></span></a></li>
            <li><a href="#tabs-2" id="contenttemplateid" class='tabActive'><span id="RVcontentPage" class='tabActive'><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Content template");?></span></a></li>
            <li><a href="#tabs-3" id="wysvdohelp" class='tabActive'><span id="contentHelp" class='tabActive'><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("WYSIWYG VDO help");?></span></a></li>
        <li style="float:right;"><div id="rvButtonDesignSource" style="position:;text-align:right;z-index: 100;display:block; margin:0px;margin-bottom:-6px; padding:0px;">
          <input type ="button" id="RVeditorZone1_design" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Design (Alt+D)");?>" style="display:none;" class="wend btnDesign btnDesign_Active" editorZone ="editorZone1" />
          <input type ="button" id="RVeditorZone1_source" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Source (Alt+S)");?>" style="display:none;" class="wend btnSource " editorZone ="editorZone1" />
          
          <input type ="button" id="RVeditorZone2_design" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Design (Alt+D)");?>" style="display:none;" class="wend btnDesign btnDesign_Active" editorZone ="editorZone2" />
          <input type ="button" id="RVeditorZone2_source" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Source (Alt+S)");?>" style="display:none;" class="wend btnSource" editorZone ="editorZone2" />
          
          <input type ="button" id="RVeditorZone3_design" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Design (Alt+D)");?>" style="display:none;" class="wend btnDesign btnDesign_Active" editorZone ="editorZone3" />
          <input type ="button" id="RVeditorZone3_source" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Source (Alt+S)");?>" style="display:none;" class="wend btnSource" editorZone ="editorZone3" />
          
          <input type ="button" id="RVeditorZone4_design" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Design (Alt+D)");?>" style="display:none;" class="wend btnDesign btnDesign_Active" editorZone ="editorZone4" />
          <input type ="button" id="RVeditorZone4_source" value="<?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'translate'))) echo $t->translate("Source (Alt+S)");?>" style="display:none;" class="wend btnSource" editorZone ="editorZone4" /> 
    </div>  </li>
		</ul>
        <div id="tabs-1" style="position:absolute;width:50%;background-image:url(<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/minilayout_bg.jpg);background-position:bottom; background-repeat:repeat-x;background-color:#FFFFFF;border:#BEBEBE solid 1px;">
            Change layout :
            <span id="viewLayoutId"><?php echo htmlspecialchars($t->currentLayout);?></span>
            
                   <div style="position: ">            
                <!--  aLayout  --> 
                <table cellspacing="10" cellpadding="0">
                    <tr>
                <?php if ($this->options['strict'] || (is_array($t->aLayout)  || is_object($t->aLayout))) foreach($t->aLayout as $k => $v) {?>
                <td align="left" valign="top">
                <input type="hidden" id="layout<?php echo htmlspecialchars($v['rvs_layout_id']);?>" name="layout<?php echo htmlspecialchars($v['rvs_layout_id']);?>" value="<?php echo htmlspecialchars($v['layout_data']);?>">
                <a href="javascript:" class="layoutDesign minilayout " focusLayOut="<?php echo htmlspecialchars($v['rvs_layout_id']);?>" focusZone ="<?php echo htmlspecialchars($v['num_of_zone']);?>">
                <img style="cursor: pointer" src ="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/layoutwysiwyg/s<?php echo htmlspecialchars($v['layout_image']);?>">
                 </a>
                </td>
                <?php }?>
                </tr>
                </table>
                <!--end  aLayout  -->    
                </div>
                </div>  
          
               <div id="tabs-2" style="display:none;"></div>
          
               <div id="tabs-3" style="display:none;"></div>
             
         </div>    
        
        
       <div id="rvTagPathWysiwyg" style="margin-top:45px;" class="wproEditor">
          <div id="RVeditorZone1_tagPath" class="wend wproTagPath BgTagPathWysiwyg" style="display:none;"></div>
          <div id="RVeditorZone2_tagPath" class="wend wproTagPath BgTagPathWysiwyg" style="display:none;"></div>
          <div id="RVeditorZone3_tagPath" class="wend wproTagPath BgTagPathWysiwyg" style="display:none;"></div>
          <div id="RVeditorZone4_tagPath" class="wend wproTagPath BgTagPathWysiwyg" style="display:none;"></div>
    </div> 
    
</div>

</div>
 <!--OPen Web Page data and contents   {bodyTemplateStyle}"-->
<div id="templateBody" style="<?php echo htmlspecialchars($t->bodyTemplateStyle);?>; width:99.2%; overflow: auto; position:absolute;">
 <!-- Toolbars and warning and errors -->
<div id="rvToolBar" style="background-color:#e8e8e8; border-top:#ffffff 1px solid;">
    <!-- Warning and errors -->
    <div align="center">
    <?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'msgGet'))) if ($t->msgGet()) { ?><span><?php if ($this->options['strict'] || (isset($t) && method_exists($t, 'msgGet'))) echo $t->msgGet();?></span><?php }?>
    <div id="err"></div>
    </div>
</div>
 <a href="#" id="iconEndFullWin" style="z-index:100000;display:none;position:absolute;margin-top:2px;cursor:pointer;left:0px;" onclick="wproE_fullWindow22(currentWPo)">
    <img border="0" src="<?php echo htmlspecialchars($t->webRoot);?>/themes/<?php echo htmlspecialchars($t->theme);?>/sitebuilder/images/icon_minimie.jpg" />
</a>
    <?php echo $t->aWygPreBody;?>
    <!--open layout wysiwyg -->
		<div id="templateEditorWysiwyg" style="">
    <div id="layoutSlider"><div id="layoutSliderBar"></div></div>
    <div id="currentLayout" style="">    
        <div id="layout_zone1" style="display: ;"></div>
        <div id="layout_zone2" style="display: none;"></div>
        <div id="layout_zone3" style="display: none;"></div>
        <div id="layout_zone4" style="display: none;"></div>
    </div>
        <?php 
if (!isset($this->elements['hidEditorZone1']->attributes['value'])) {
    $this->elements['hidEditorZone1']->attributes['value'] = '';
    $this->elements['hidEditorZone1']->attributes['value'] .=  $t->editorZone1;
}
$_attributes_used = array('value');
echo $this->elements['hidEditorZone1']->toHtml();
if (isset($_attributes_used)) {  foreach($_attributes_used as $_a) {
    unset($this->elements['hidEditorZone1']->attributes[$_a]);
}}
?>
    <?php 
if (!isset($this->elements['hidEditorZone2']->attributes['value'])) {
    $this->elements['hidEditorZone2']->attributes['value'] = '';
    $this->elements['hidEditorZone2']->attributes['value'] .=  $t->editorZone2;
}
$_attributes_used = array('value');
echo $this->elements['hidEditorZone2']->toHtml();
if (isset($_attributes_used)) {  foreach($_attributes_used as $_a) {
    unset($this->elements['hidEditorZone2']->attributes[$_a]);
}}
?>
    <?php 
if (!isset($this->elements['hidEditorZone3']->attributes['value'])) {
    $this->elements['hidEditorZone3']->attributes['value'] = '';
    $this->elements['hidEditorZone3']->attributes['value'] .=  $t->editorZone3;
}
$_attributes_used = array('value');
echo $this->elements['hidEditorZone3']->toHtml();
if (isset($_attributes_used)) {  foreach($_attributes_used as $_a) {
    unset($this->elements['hidEditorZone3']->attributes[$_a]);
}}
?>
    <?php 
if (!isset($this->elements['hidEditorZone4']->attributes['value'])) {
    $this->elements['hidEditorZone4']->attributes['value'] = '';
    $this->elements['hidEditorZone4']->attributes['value'] .=  $t->editorZone4;
}
$_attributes_used = array('value');
echo $this->elements['hidEditorZone4']->toHtml();
if (isset($_attributes_used)) {  foreach($_attributes_used as $_a) {
    unset($this->elements['hidEditorZone4']->attributes[$_a]);
}}
?>
	</div>
    <?php echo $t->aWygPostBody;?>
</div>

 <!--Close Web Page data and contents -->

 <?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('dialog/wysiwyg.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>
 <?php 
$x = new HTML_Template_Flexy($this->options);
$x->compile('scriptWysiwygStep5.html');
$_t = function_exists('clone') ? clone($t) : $t;
foreach(get_defined_vars()  as $k=>$v) {
    if ($k != 't') { $_t->$k = $v; }
}
$x->outputObject($_t, $this->elements);
?>