[template]
xml_lang=fi
charset_name=finnish
charset=utf-8
project_logo=NOPIC
font_css=Verdana.css
navigator_css_url="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/a83daea9743a13bbb3d0b69a566e540d.css?ABCSESS=f4c0067bd5c73c7b08cb5df29ccb1209"
