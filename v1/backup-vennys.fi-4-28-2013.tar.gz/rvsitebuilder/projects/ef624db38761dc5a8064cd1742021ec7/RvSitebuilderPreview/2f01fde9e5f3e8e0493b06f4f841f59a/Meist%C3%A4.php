<?php echo '<?xml version="1.0" encoding="utf-8"?>'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fi" lang="fi">
<head>
<title>vennys12011</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta name="generator" content="Kotisivukone" />
<meta name="progid" content="Version: 4.69 PRO; Project name: vennys; Project id: ef624db38761dc5a8064cd1742021ec7; Template Name: pro_2-552-1_darkgreen_beauty_2; Published date: March 20, 2011, 9:42 10 (GMT +02:00" />
 
<link rel="stylesheet" href="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/style.css" type="text/css" />
<link rel="stylesheet" href="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/Verdana.css" type="text/css" />
<link rel="stylesheet" href="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/54e35b2712008e74e3d2699960693e07.css" type="text/css" />
<link rel="stylesheet" href="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/pathway.css" type="text/css" />

<script  type="text/javascript" src="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/rvsincludefile/rvsheadpage.js"></script>


<script type="text/javascript" src="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/rvsincludefile/rvsnavigator.js"></script>
<script type="text/javascript" src="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/js/publishNavigator/layersmenu-library.js"></script>
<script type="text/javascript" src="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/js/publishNavigator/layersmenu.js"></script>

<script  type="text/javascript" src="https://cpanel.4c.hostingpalvelu.fi/3rdparty/rvsitebuilder/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/rvsincludefile/rvscustomopenwindow.js"></script>

</head>

<body>
<table cellpadding="0" cellspacing="0" id="rv_top_adjust_width_0" width="100%" align="center" >
	<tr>
		<td align="left" valign="top" class="bgtop">
			<!-- START LOGO -->
				<div style="position: absolute;">
					<div id="Layer1" style="position:relative; left:784px; top:164px; width:120; height:60; text-align:center; z-index:1; overflow:visible; white-space:nowrap;"><!-- START LOGO --><!-- END LOGO --></div>
				</div>
				<div style="position: absolute;">
					<div id="Layer2" style="position:relative; left:36px; top:29px; width:auto; height:auto; text-align:left; z-index:2; overflow:visible; white-space:nowrap;" class="company"><div><strong><font style="font-size: 24px" face="Verdana">Venny'S Hiusmuotoilua&nbsp;</font></strong></div></div>
				</div>
				<div style="position: absolute;">
					<div id="Layer3" style="position:relative; left:195px; top:88px; width:auto; height:auto; text-align:left; z-index:3; overflow:visible; white-space:nowrap;" class="slogan"><div><font style="font-size: 16px"></font><em><font style="font-size: 18px"><font face="Verdana"><strong>Tukka kuntoon ja baanalle ...</strong>&nbsp;</font></font></em></div></div>
				</div>
			<!-- END LOGO -->
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td align="left" valign="top"><img src="images/img_01.jpg" alt="" width="180" height="134" /></td>
					<td width="99%"></td>				 								
					<td align="left" valign="top"><img src="images/img_02.jpg" alt="" width="220" height="134" /></td>
					<td align="left" valign="top"><img src="images/img_03.jpg" alt="" width="200" height="134" /></td>
					<td align="left" valign="top"><img src="images/img_04.jpg" alt="" width="180" height="134" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td align="left" valign="top">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td align="left" valign="top"><img src="images/img_05.jpg" alt="" width="18" height="12" /></td>
					<td align="left" valign="top" width="99%">
						<table cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td align="left" valign="top">
									<table cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td align="left" valign="top" class="bgnav"><img src="images/img_07.jpg" alt="" width="14" height="12" /></td>
											<td rowspan="2" align="left" valign="top" width="99%">
												<table cellpadding="0" cellspacing="0" width="100%">
													<tr>
														<td align="left" valign="top" height="32" class="bgmenu"><div class="navigator">
<ul class="navigator">
<li><a href="index.php"  class="normal"  target="_self" ><span>Etusivu</span></a></li>
<li><a href="Meist%C3%A4.php" id="current"   target="_self" ><span>Meistä</span></a></li>
</ul>
</div>

</td>
													</tr>
												</table>
											</td>
											<td align="right" valign="top" class="bgnav"><img src="images/img_08.jpg" alt="" width="14" height="12" /></td>
										</tr>
										<tr>
											<td align="left" valign="bottom" class="bgnav"><img src="images/img_09.jpg" alt="" width="14" height="10" /></td>
											<td align="right" valign="bottom" class="bgnav"><img src="images/img_10.jpg" alt="" width="14" height="10" /></td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td align="left" valign="top" width="99%" bgcolor="#FFFFFF">
									<table cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td align="left" valign="top"><img src="images/img_11.jpg" alt="" width="14" height="19" /></td>
											<td class="line02"><img src="images/spacer.gif" alt="" width="1" height="19" /></td>
											<td align="left" valign="top"><img src="images/img_12.jpg" alt="" width="14" height="19" /></td>
										</tr>
										<tr>
											<td class="exl" valign="top"><img src="images/spacer.gif" alt="" width="1" height="338" /></td>
											<td align="left" valign="top" width="99%">
												<table cellpadding="0" cellspacing="0" width="100%">
													 	

													<!-- Begin PATHWAY and ICON -->
													<tr>
														<td class="magin">
															<table cellpadding="0" cellspacing="0" width="100%">
																<tr>
																	<!-- Begin PATHWAY -->
																	<td align="left" width="99%"><?php include("/var/cpanel/rvglobalsoft/rvsitebuilder/www/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/rvsincludefile/pathway_0b2e6894018b1527ca1307335383cb50.html"); ?></td>
																	<!-- End PATHWAY -->
																	<!-- Begin ICON -->
																	<td align="right"><?php include("/var/cpanel/rvglobalsoft/rvsitebuilder/www/project/ef624db38761dc5a8064cd1742021ec7/RvSitebuilderPreview/2f01fde9e5f3e8e0493b06f4f841f59a/rvsincludefile/icon_0b2e6894018b1527ca1307335383cb50.html"); ?></td>
																	<!-- End ICON -->
																</tr>
															</table>																		
														</td>
													</tr>
													<!-- End PATHWAY and ICON -->
													<tr>
														<td align="left" valign="top">
															<table cellpadding="0" cellspacing="0" width="100%">
																<tr>
																	 

																	<td align="left" valign="top" class="magin" id="rv_adjust_width_65" width="100%">

<style type="text/css"><!--.block_01{ font-size:11px;}h2.text16{ font-size:16px; padding:0px; margin:0px;} h3.text14{ font-size:14px; padding:0px; margin:0px;} h4.text12{ font-size:12px; padding:0px; margin:0px;} h5.text11{ font-size:11px; padding:0px; margin:0px;}h6.text10{ font-size:10px; padding:0px; margin:0px;}--></style><table cellpadding="0" cellspacing="0" width="100%" class="block_01"> <tr> <td align="left" valign="top" width="100%" id="layout_zone1" style = ""></td>  <tr> <td align="left" valign="top" width="100%" id="layout_zone2" style = ""></td>  </tr></table>
</td>
																	 

																</tr>
															</table>														
														</td>
													</tr>
													<!-- Begin FOOTER -->
													<tr>
														<td align="center" class="magin"></td>
													</tr>
													<!-- End FOOTER -->
													 

													<tr>
														<td height="25" align="center" valign="bottom">
															<table cellpadding="0" cellspacing="0">
																<tr>
																	<td align="center" valign="bottom" class="marginpw"></td>
																	<td width="8"></td>
																	<td align="center" valign="bottom" class="marginpw"></td>
																</tr>
															</table>			
														</td>
													</tr>
												</table>
											</td>
											<td class="exr" valign="top"><img src="images/spacer.gif" alt="" width="1" height="338" /></td>
										</tr>
										<tr>
											<td align="left" valign="top"><img src="images/img_13.jpg" alt="" width="14" height="14" /></td>
											<td class="bgbottom"><img src="images/spacer.gif" alt="" width="1" height="14" /></td>
											<td align="left" valign="top"><img src="images/img_14.jpg" alt="" width="14" height="14" /></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
					<td align="left" valign="top"><img src="images/img_06.jpg" alt="" width="19" height="12" /></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>
